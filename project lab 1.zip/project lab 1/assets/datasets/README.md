# Sample datasets — ProjectLab

All datasets in this folder are **synthetic**. They were generated for teaching purposes only and do not represent any real person, company or transaction. Column names, ranges and values were designed to make specific concepts teachable. Do not present them as real data in a portfolio or interview.

| File | Used by | Purpose |
|---|---|---|
| `expenses_sample.csv` | Personal Expense Tracker (Python) | ~32 sample expense rows across a month |
| `retail_sample.sql` | Retail Database Analysis (SQL) | Schema + seed data for a small retail store |
| `sales_sample.csv` | Sales Performance Dashboard | Synthetic retail sales |
| `housing_sample.csv` | House Price Prediction | Synthetic housing data |
| `churn_sample.csv` | Customer Churn Prediction | Synthetic churn data |
| `statements_sample.csv` | Financial Statement Analysis | Synthetic financial statements |