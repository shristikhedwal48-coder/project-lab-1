-- ProjectLab synthetic retail sample database (SQLite-compatible).

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
  customer_id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  region TEXT NOT NULL,
  signup_date TEXT NOT NULL
);

CREATE TABLE products (
  product_id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  unit_price REAL NOT NULL
);

CREATE TABLE orders (
  order_id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL,
  order_date TEXT NOT NULL,
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
  order_item_id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(order_id),
  FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO customers (customer_id, name, region, signup_date) VALUES
  (1, 'Customer A', 'North', '2024-01-10'),
  (2, 'Customer B', 'South', '2024-01-15'),
  (3, 'Customer C', 'East',  '2024-02-01'),
  (4, 'Customer D', 'West',  '2024-02-12'),
  (5, 'Customer E', 'North', '2024-03-03'),
  (6, 'Customer F', 'South', '2024-03-20'),
  (7, 'Customer G', 'East',  '2024-04-05'),
  (8, 'Customer H', 'West',  '2024-04-18');

INSERT INTO products (product_id, name, category, unit_price) VALUES
  (1, 'Notebook',       'Stationery', 3.50),
  (2, 'Pen pack',       'Stationery', 5.00),
  (3, 'Desk lamp',      'Home',       24.00),
  (4, 'Coffee mug',     'Home',       8.50),
  (5, 'Wireless mouse', 'Electronics',19.99),
  (6, 'USB hub',        'Electronics',14.50),
  (7, 'Backpack',       'Bags',       39.00),
  (8, 'Water bottle',   'Home',       11.00);

INSERT INTO orders (order_id, customer_id, order_date) VALUES
  (1, 1, '2024-04-02'),
  (2, 2, '2024-04-03'),
  (3, 1, '2024-04-05'),
  (4, 3, '2024-04-06'),
  (5, 4, '2024-04-08'),
  (6, 5, '2024-04-10'),
  (7, 2, '2024-04-12'),
  (8, 6, '2024-04-14'),
  (9, 7, '2024-04-16'),
  (10, 8, '2024-04-18'),
  (11, 1, '2024-04-20'),
  (12, 3, '2024-04-22');

INSERT INTO order_items (order_item_id, order_id, product_id, quantity) VALUES
  (1,  1, 1, 3),
  (2,  1, 2, 1),
  (3,  2, 3, 1),
  (4,  2, 4, 2),
  (5,  3, 5, 1),
  (6,  4, 7, 1),
  (7,  4, 8, 1),
  (8,  5, 2, 4),
  (9,  5, 1, 2),
  (10, 6, 6, 1),
  (11, 7, 4, 1),
  (12, 7, 3, 1),
  (13, 8, 7, 1),
  (14, 9, 5, 1),
  (15, 9, 6, 1),
  (16, 10, 8, 2),
  (17, 11, 2, 3),
  (18, 12, 4, 2);