export function renderFooter() {
  const year = new Date().getFullYear();
  return `
    <footer class="footer">
      <div class="container">
        <div class="footer-grid">
          <div>
            <a class="brand" href="index.html">
              <span class="brand-mark">PL</span>
              <span>ProjectLab</span>
            </a>
            <p style="margin-top: 12px; font-size: var(--fs-sm);">
              Don't just learn the skill. Build with it.
            </p>
          </div>
          <div>
            <h4>Platform</h4>
            <ul>
              <li><a href="explore.html">Explore Skills</a></li>
              <li><a href="workspace-python.html">Python Lab</a></li>
              <li><a href="workspace-sql.html">SQL Lab</a></li>
              <li><a href="dashboard.html">Dashboard</a></li>
            </ul>
          </div>
          <div>
            <h4>Subjects</h4>
            <ul>
              <li><a href="explore.html">Programming</a></li>
              <li><a href="explore.html">Data Science</a></li>
              <li><a href="explore.html">AI &amp; ML</a></li>
              <li><a href="explore.html">Finance</a></li>
            </ul>
          </div>
          <div>
            <h4>Portfolio</h4>
            <ul>
              <li><a href="portfolio.html">My Portfolio</a></li>
              <li><a href="assessment.html?subject=python">Python Assessment</a></li>
              <li><a href="assessment.html?subject=sql">SQL Assessment</a></li>
            </ul>
          </div>
        </div>
        <div class="footer-bottom">
          <span>&copy; ${year} ProjectLab. Educational platform.</span>
          <span>Built for learners who ship.</span>
        </div>
      </div>
    </footer>
  `;
}