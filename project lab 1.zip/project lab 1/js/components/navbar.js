export function renderNavbar() {
  return `
    <nav class="navbar" aria-label="Primary">
      <div class="container navbar-inner">
        <a class="brand" href="index.html" aria-label="ProjectLab home">
          <span class="brand-mark">PL</span>
          <span>ProjectLab</span>
        </a>
        <ul class="nav-links">
          <li><a href="index.html">Home</a></li>
          <li><a href="explore.html">Explore Skills</a></li>
          <li><a href="workspace-python.html">Python Lab</a></li>
          <li><a href="workspace-sql.html">SQL Lab</a></li>
          <li><a href="dashboard.html">Dashboard</a></li>
          <li><a href="portfolio.html">Portfolio</a></li>
        </ul>
        <div class="nav-actions">
          <button id="theme-toggle" class="icon-btn" aria-label="Toggle light and dark theme" title="Toggle theme">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <circle cx="12" cy="12" r="4"/>
              <path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/>
            </svg>
          </button>
          <button id="nav-toggle" class="icon-btn nav-toggle" aria-label="Toggle menu" aria-expanded="false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <path d="M3 6h18M3 12h18M3 18h18"/>
            </svg>
          </button>
        </div>
      </div>
    </nav>
  `;
}