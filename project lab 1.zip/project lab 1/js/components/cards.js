export function pathCard(subject) {
  const stages = Array.from({ length: 6 }, (_, i) =>
    `<span class="${i < 2 ? 'on' : ''}" aria-hidden="true"></span>`
  ).join('');

  return `
    <article class="card card-click path-card" data-subject-id="${subject.id}">
      <div class="path-meta">
        <span class="tag tag-level-${subject.level}">${capitalize(subject.level)}</span>
        <span class="tag">${subject.duration}</span>
      </div>
      <h3>${subject.name}</h3>
      <p>${subject.blurb}</p>
      <div class="path-stages" title="6-stage methodology">${stages}</div>
      <a class="link-arrow" href="subject.html?id=${subject.id}">Open learning path →</a>
    </article>
  `;
}

export function projectCard(project) {
  return `
    <article class="card project-card">
      <div class="proj-head">
        <h3>${project.title}</h3>
        <span class="tag tag-level-${project.difficulty}">${capitalize(project.difficulty)}</span>
      </div>
      <div class="proj-meta">
        <span>${project.duration}</span>
        <span>${project.industry}</span>
        <span>6-stage</span>
      </div>
      <p>${project.blurb}</p>
      <a class="link-arrow" href="project.html?id=${project.id}">Open project →</a>
    </article>
  `;
}

export function subjectCard(subject) {
  return `
    <article class="card card-click subject-card" data-subject-id="${subject.id}">
      <h3>${subject.name}</h3>
      <p>${subject.blurb}</p>
      <div class="subj-foot">
        <span class="tag tag-level-${subject.level}">${capitalize(subject.level)}</span>
        <a class="link-arrow" href="subject.html?id=${subject.id}">Open →</a>
      </div>
    </article>
  `;
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}