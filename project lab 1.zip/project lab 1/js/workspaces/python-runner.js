let worker = null;
let seq = 0;
const pending = new Map();

function ensureWorker(onStatus) {
  if (worker) return worker;
  worker = new Worker(new URL('./python-worker.js', import.meta.url), { type: 'classic' });
  worker.onmessage = (ev) => {
    const { id, ok, stdout, stderr } = ev.data;
    const resolver = pending.get(id);
    if (resolver) {
      resolver({ ok, stdout, stderr });
      pending.delete(id);
    }
  };
  worker.onerror = (e) => {
    pending.forEach(res => res({ ok: false, stdout: '', stderr: 'Worker error: ' + e.message }));
    pending.clear();
  };
  if (onStatus) onStatus('ready');
  return worker;
}

export function runPython(code, options) {
  const opts = options || {};
  const files = opts.files || [];
  const onStatus = opts.onStatus;
  return new Promise((resolve) => {
    const w = ensureWorker(onStatus);
    const id = ++seq;
    pending.set(id, resolve);
    w.postMessage({ id, code, files });
  });
}