const PY_HINTS = [
  {
    match: /NameError: name '([^']+)' is not defined/,
    explain: (m) => `Python does not know the name "${m[1]}".`,
    fix: (m) => `Check spelling and capitalisation. If it is a variable, make sure you assigned it before this line. If it is a function or module, check you imported it (e.g. \`import ${m[1]}\`).`,
  },
  {
    match: /TypeError: unsupported operand type\(s\) for \+: '([^']+)' and '([^']+)'/,
    explain: (m) => `You are trying to add a ${m[1]} and a ${m[2]}.`,
    fix: () => 'Convert one side to match the other. For numeric addition, use float() or int() on the string value.',
  },
  {
    match: /KeyError: '([^']+)'/,
    explain: (m) => `A dict has no key "${m[1]}".`,
    fix: () => 'Check the exact key. If reading from a file, print the first row to see the real keys. Consider dict.get(key, default) to avoid this on first access.',
  },
  {
    match: /IndexError: list index out of range/,
    explain: () => 'You accessed a list position that does not exist.',
    fix: () => 'Print len(your_list) before the access. Indices start at 0, so a list of length 5 has indices 0–4.',
  },
  {
    match: /FileNotFoundError: \[Errno 2\] No such file or directory: '([^']+)'/,
    explain: (m) => `The file "${m[1]}" was not found.`,
    fix: () => 'In this browser workspace, files must be uploaded or inlined — your local disk is not visible. In a local environment, run the script from the folder containing the file.',
  },
  {
    match: /IndentationError: (unexpected indent|expected an indented block)/,
    explain: () => 'Python is sensitive to indentation.',
    fix: () => 'Use consistent indentation (spaces, usually 4). Make sure the line after a colon (if/for/def/class) is indented.',
  },
  {
    match: /SyntaxError: invalid syntax/,
    explain: () => 'Python could not parse the code.',
    fix: () => 'Check for a missing colon, bracket or quote. The line number in the traceback points to where parsing failed — often the problem is on the line just above.',
  },
  {
    match: /ZeroDivisionError: division by zero/,
    explain: () => 'You divided by zero.',
    fix: () => 'Guard the division: `if denominator != 0: result = num / denom`.',
  },
  {
    match: /AttributeError: '([^']+)' object has no attribute '([^']+)'/,
    explain: (m) => `A ${m[1]} does not have a .${m[2]} attribute.`,
    fix: (m) => `Print the object to confirm its type. For dicts use ["${m[2]}"]; for lists use .append (not .add).`,
  },
];

const SQL_HINTS = [
  {
    match: /no such table: ([A-Za-z0-9_]+)/i,
    explain: (m) => `The table "${m[1]}" does not exist in this database.`,
    fix: () => 'Check the schema panel on the left. Table names must match exactly.',
  },
  {
    match: /no such column: ([A-Za-z0-9_.]+)/i,
    explain: (m) => `The column "${m[1]}" does not exist.`,
    fix: () => 'Check the schema panel. If you aliased a table (e.g. `orders o`), prefix the column with the alias: `o.order_id`.',
  },
  {
    match: /syntax error near "([^"]+)"/i,
    explain: (m) => `SQLite could not parse the query at "${m[1]}".`,
    fix: () => 'Check clause order: SELECT … FROM … JOIN … ON … WHERE … GROUP BY … ORDER BY … LIMIT.',
  },
  {
    match: /ambiguous column name: ([A-Za-z0-9_.]+)/i,
    explain: (m) => `The column "${m[1]}" exists in more than one joined table.`,
    fix: () => 'Prefix the column with the table name or alias.',
  },
  {
    match: /misuse of aggregate: ([A-Za-z0-9_]+)/i,
    explain: (m) => `Aggregate "${m[1]}" used in a place where SQLite does not allow it (usually WHERE).`,
    fix: () => 'Aggregates belong in SELECT or HAVING, not WHERE.',
  },
];

export function explainPythonError(message) {
  for (const h of PY_HINTS) {
    const m = message.match(h.match);
    if (m) return { title: h.explain(m), fix: h.fix(m) };
  }
  return {
    title: 'Python reported an error.',
    fix: 'Read the last line of the traceback first — it says what went wrong. The line number above it tells you where.',
  };
}

export function explainSqlError(message) {
  for (const h of SQL_HINTS) {
    const m = message.match(h.match);
    if (m) return { title: h.explain(m), fix: h.fix(m) };
  }
  return {
    title: 'SQLite reported an error.',
    fix: 'Check that table and column names match the schema panel. Verify JOINs have an ON clause.',
  };
}