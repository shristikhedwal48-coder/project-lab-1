let pyodideReady = null;

async function getPyodide() {
  if (pyodideReady) return pyodideReady;
  pyodideReady = (async () => {
    importScripts('https://cdn.jsdelivr.net/pyodide/v0.25.1/full/pyodide.js');
    return await loadPyodide({
      indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.25.1/full/',
    });
  })();
  return pyodideReady;
}

self.onmessage = async (event) => {
  const data = event.data;
  const id = data.id;
  const code = data.code;
  const files = data.files || [];
  const outputs = [];

  try {
    const pyodide = await getPyodide();

    pyodide.globals.set('__pl_write', (s) => { outputs.push(String(s)); });

    await pyodide.runPythonAsync(
      'import sys\n' +
      'class _PLOut:\n' +
      '    def write(self, s):\n' +
      '        if s: __pl_write(s)\n' +
      '    def flush(self): pass\n' +
      'sys.stdout = _PLOut()\n' +
      'sys.stderr = _PLOut()\n'
    );

    if (files.length) {
      for (const f of files) {
        pyodide.FS.writeFile(f.name, f.content, { encoding: 'utf8' });
      }
    }

    await pyodide.runPythonAsync(code);

    await pyodide.runPythonAsync('import sys; sys.stdout = sys.__stdout__; sys.stderr = sys.__stderr__');

    self.postMessage({
      id,
      ok: true,
      stdout: outputs.join(''),
      stderr: '',
    });
  } catch (err) {
    try {
      const p = await pyodideReady;
      await p.runPythonAsync('import sys; sys.stdout = sys.__stdout__; sys.stderr = sys.__stderr__');
    } catch (_) {}

    const message = (err && (err.message || String(err))) || 'Unknown error';
    self.postMessage({
      id,
      ok: false,
      stdout: outputs.join(''),
      stderr: message,
    });
  }
};