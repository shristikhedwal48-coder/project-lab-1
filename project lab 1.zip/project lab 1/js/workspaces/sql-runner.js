let sqlJs = null;
let db = null;
let seed = null;

export async function initSql(seedSql) {
  if (!sqlJs) {
    sqlJs = await loadSqlJs();
  }
  seed = seedSql;
  db = new sqlJs.Database();
  if (seedSql) db.run(seedSql);
  return db;
}

export function resetToSeed() {
  if (!sqlJs || !seed) throw new Error('SQL not initialized');
  db.close();
  db = new sqlJs.Database();
  db.run(seed);
  return db;
}

export function runSql(sql) {
  if (!db) throw new Error('SQL not initialized');
  const isSelect = /^\s*(select|with|pragma)/i.test(sql);
  if (isSelect) {
    const results = db.exec(sql);
    if (results.length === 0) {
      return { rows: [], columns: [], changes: 0, isSelect: true };
    }
    const r = results[0];
    const columns = r.columns;
    const rows = r.values.map((arr) => {
      const obj = {};
      columns.forEach((c, i) => { obj[c] = arr[i]; });
      return obj;
    });
    return { rows, columns, changes: 0, isSelect: true };
  } else {
    db.run(sql);
    return { rows: [], columns: [], changes: db.getRowsModified(), isSelect: false };
  }
}

export function getSchema() {
  if (!db) return [];
  const t = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;");
  if (t.length === 0) return [];
  return t[0].values.map((row) => {
    const name = row[0];
    const info = db.exec('PRAGMA table_info("' + name.replace(/"/g, '""') + '");');
    const cols = (info[0] ? info[0].values : []).map((c) => ({
      name: c[1],
      type: c[2],
      primaryKey: c[5] === 1,
      notNull: c[3] === 1,
    }));
    return { name, columns: cols };
  });
}

async function loadSqlJs() {
  if (window.initSqlJs) {
    return await window.initSqlJs({
      locateFile: (f) => 'https://cdn.jsdelivr.net/npm/sql.js@1.10.2/dist/' + f,
    });
  }
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/sql.js@1.10.2/dist/sql-wasm.js';
    s.onload = async () => {
      try {
        const SQL = await window.initSqlJs({
          locateFile: (f) => 'https://cdn.jsdelivr.net/npm/sql.js@1.10.2/dist/' + f,
        });
        resolve(SQL);
      } catch (err) {
        reject(err);
      }
    };
    s.onerror = () => reject(new Error('sql.js CDN unavailable'));
    document.head.appendChild(s);
    setTimeout(() => reject(new Error('sql.js load timeout')), 15000);
  });
}