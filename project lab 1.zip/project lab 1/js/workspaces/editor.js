export async function createEditor(mountEl, { language = 'python', initial = '' } = {}) {
  const monaco = await loadMonaco().catch(() => null);
  if (monaco) {
    const editor = monaco.editor.create(mountEl, {
      value: initial,
      language,
      theme: document.documentElement.getAttribute('data-theme') === 'dark' ? 'vs-dark' : 'vs',
      automaticLayout: true,
      fontSize: 13,
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      tabSize: 2,
    });
    return {
      getValue: () => editor.getValue(),
      setValue: (v) => editor.setValue(v),
      focus: () => editor.focus(),
      dispose: () => editor.dispose(),
      mode: 'monaco',
    };
  }

  const ta = document.createElement('textarea');
  ta.id = 'editor';
  ta.spellcheck = false;
  ta.value = initial;
  ta.setAttribute('aria-label', language + ' code editor');
  mountEl.appendChild(ta);
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = ta.selectionStart;
      const en = ta.selectionEnd;
      ta.value = ta.value.slice(0, s) + '  ' + ta.value.slice(en);
      ta.selectionStart = ta.selectionEnd = s + 2;
    }
  });
  return {
    getValue: () => ta.value,
    setValue: (v) => { ta.value = v; },
    focus: () => ta.focus(),
    dispose: () => ta.remove(),
    mode: 'textarea',
  };
}

let monacoLoadPromise = null;

function loadMonaco() {
  if (monacoLoadPromise) return monacoLoadPromise;
  monacoLoadPromise = new Promise((resolve, reject) => {
    if (window.monaco) return resolve(window.monaco);
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs/loader.js';
    s.onerror = () => reject(new Error('monaco CDN unavailable'));
    s.onload = () => {
      window.require.config({
        paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' },
      });
      window.require(
        ['vs/editor/editor.main'],
        () => resolve(window.monaco),
        () => reject(new Error('monaco failed to init'))
      );
    };
    document.head.appendChild(s);
    setTimeout(() => reject(new Error('monaco timeout')), 6000);
  });
  return monacoLoadPromise;
}