import { getProgress } from '../store.js';
import { getSubjectById } from '../data/subjects.js';

const root = document.getElementById('root');

(async function boot() {
  const p = await getProgress();
  render(p);
})();

function render(p) {
  const subjects = p.subjectsExplored.map(id => getSubjectById(id)).filter(Boolean);
  const startedIds = Object.keys(p.projectsStarted || {});
  const completedIds = Object.keys(p.projectsCompleted || {});
  const exerciseCount = Object.keys(p.exercisesCompleted || {}).length;
  const assessmentsCount = Object.keys(p.assessments || {}).length;

  document.title = 'Dashboard — ProjectLab';

  const subjectsHtml = subjects.length
    ? '<div class="grid grid-3">' + subjects.map(s =>
        '<a class="card card-click" href="subject.html?id=' + s.id + '" style="display:block;color:inherit">' +
          '<strong>' + esc(s.name) + '</strong>' +
          '<p style="margin:4px 0 0;font-size:14px;color:var(--text-muted)">' + esc(s.duration) + '</p>' +
        '</a>'
      ).join('') + '</div>'
    : '<p style="color:var(--text-muted)">You haven\'t explored any subjects yet. <a href="explore.html">Start exploring →</a></p>';

  const assessmentsHtml = assessmentsCount
    ? renderAssessments(p.assessments)
    : '<p style="color:var(--text-muted)">No assessments yet. <a href="assessment.html?subject=python">Try the Python assessment</a> or <a href="assessment.html?subject=sql">the SQL assessment</a>.</p>';

  root.innerHTML =
    '<section class="section" style="padding-top:32px"><div class="container">' +
      '<h1>Your Dashboard</h1>' +
      '<p style="max-width:620px">Progress is stored in your browser (IndexedDB, with localStorage fallback). Nothing is uploaded anywhere.</p>' +
      '<div class="grid grid-4" style="margin-top:24px">' +
        statCard(subjects.length, 'Subjects explored') +
        statCard(startedIds.length, 'Projects started') +
        statCard(completedIds.length, 'Projects completed') +
        statCard(exerciseCount, 'Exercises completed') +
      '</div>' +
      '<h2 style="margin-top:32px">Subjects explored</h2>' + subjectsHtml +
      '<h2 style="margin-top:32px">Assessments taken</h2>' + assessmentsHtml +
      '<h2 style="margin-top:32px">Workspaces</h2>' +
      '<div class="grid grid-2">' +
        '<a class="card card-click" href="workspace-python.html" style="display:block;color:inherit">' +
          '<h3 style="margin:0">Python Workspace</h3>' +
          '<p style="margin:4px 0 0;font-size:14px;color:var(--text-muted)">In-browser Python exercises</p>' +
        '</a>' +
        '<a class="card card-click" href="workspace-sql.html" style="display:block;color:inherit">' +
          '<h3 style="margin:0">SQL Workspace</h3>' +
          '<p style="margin:4px 0 0;font-size:14px;color:var(--text-muted)">In-browser SQLite exercises</p>' +
        '</a>' +
      '</div>' +
      '<h2 style="margin-top:32px">Portfolio</h2>' +
      '<p><a href="portfolio.html">View your portfolio →</a></p>' +
    '</div></section>';
}

function statCard(value, label) {
  return '<div class="card">' +
    '<h3 style="font-size:1.75rem;margin:0">' + value + '</h3>' +
    '<p style="margin:4px 0 0;font-size:14px">' + esc(label) + '</p>' +
    '</div>';
}

function renderAssessments(assessments) {
  return '<div class="grid grid-2">' +
    Object.entries(assessments).map(([id, a]) => {
      const s = getSubjectById(id);
      const pct = Math.round((a.score / a.total) * 100);
      const name = s ? s.name : id;
      return '<div class="card">' +
        '<strong>' + esc(name) + '</strong>' +
        '<p style="margin:4px 0 0;font-size:14px;color:var(--text-muted)">Score ' + a.score + ' / ' + a.total + ' (' + pct + '%) · ' + new Date(a.submittedAt).toLocaleDateString() + '</p>' +
        '<a class="link-arrow" href="assessment.html?subject=' + id + '">Retake →</a>' +
        '</div>';
    }).join('') +
    '</div>';
}

function esc(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}