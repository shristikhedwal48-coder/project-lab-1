import { getSubjectById } from '../data/subjects.js';
import { getProjectsBySubject } from '../data/projects.js';
import { projectCard } from '../components/cards.js';
import { getAssessment } from '../data/assessments.js';
import { recordSubjectExplored } from '../store.js';

const root = document.getElementById('root');
const id = new URLSearchParams(location.search).get('id');
const subject = getSubjectById(id);

if (!subject) {
  root.innerHTML = '<section class="section"><div class="container empty-state"><h2>Subject not found</h2><p>The learning path you requested does not exist.</p><a href="explore.html" class="btn btn-primary">Browse all subjects</a></div></section>';
} else {
  document.title = subject.name + ' — ProjectLab';
  const projects = getProjectsBySubject(subject.id);
  const hasAssessment = getAssessment(subject.id);

  const modulesHtml = subject.modules.map((m, i) => {
    const projectsList = (m.projects && m.projects.length)
      ? '<p style="font-size:14px;margin:16px 0 6px"><strong>Projects:</strong></p><ul class="project-list">' +
        m.projects.map(p => '<li><span>' + p + '</span><span class="tag tag-brand">6-stage</span></li>').join('') +
        '</ul>'
      : '';
    return '<article class="curriculum-module" id="module-' + i + '">' +
      '<div class="module-head">' +
        '<div><span class="tag tag-level-' + m.level + '">' + cap(m.level) + '</span><h3 style="margin-top:8px">' + m.title + '</h3></div>' +
        '<span class="tag">Module ' + (i + 1) + '</span>' +
      '</div>' +
      '<p style="font-size:14px;margin:0 0 8px"><strong>You will learn to:</strong></p>' +
      '<ul class="module-objectives">' + m.objectives.map(o => '<li>' + o + '</li>').join('') + '</ul>' +
      projectsList +
      '</article>';
  }).join('');

  const sidebarModules = subject.modules.map((m, i) =>
    '<li><a href="#module-' + i + '">' + m.title + '</a></li>'
  ).join('');

  const projectsHtml = projects.length
    ? '<div class="grid grid-2">' + projects.map(projectCard).join('') + '</div>'
    : '<p style="color:var(--text-muted)">Projects for this path are being added. The curriculum above defines what you will build.</p>';

  root.innerHTML =
    '<section class="subject-hero"><div class="container">' +
      '<nav style="font-size:14px;color:var(--text-faint);margin-bottom:12px"><a href="explore.html">Explore</a> / ' + categoryName(subject.category) + ' / <span>' + subject.name + '</span></nav>' +
      '<h1>' + subject.name + '</h1>' +
      '<div class="subject-meta">' +
        '<span class="tag tag-level-' + subject.level + '">' + cap(subject.level) + '</span>' +
        '<span class="tag">' + subject.duration + '</span>' +
        '<span class="tag">' + subject.modules.length + ' module' + (subject.modules.length === 1 ? '' : 's') + '</span>' +
        '<span class="tag">6-stage methodology</span>' +
      '</div>' +
      '<p style="max-width:720px">' + subject.blurb + '</p>' +
    '</div></section>' +
    '<div class="container subject-layout">' +
      '<aside class="sidebar">' +
        '<h4>Curriculum</h4>' +
        '<ol>' + sidebarModules + '</ol>' +
      '</aside>' +
      '<div>' +
        '<section class="overview-box">' +
          '<h2 style="font-size:1.75rem;margin-bottom:12px">Overview</h2>' +
          '<p>This path teaches <strong>' + subject.name + '</strong> through the six-stage ProjectLab methodology.</p>' +
          '<h4 style="margin-top:16px">Prerequisites</h4>' +
          '<ul>' + subject.prerequisites.map(p => '<li>' + p + '</li>').join('') + '</ul>' +
        '</section>' +
        '<section class="overview-box">' +
          '<h2 style="font-size:1.75rem;margin-bottom:12px">Learning objectives</h2>' +
          '<ul>' + subject.objectives.map(o => '<li>' + o + '</li>').join('') + '</ul>' +
        '</section>' +
        '<section style="margin-bottom:32px">' +
          '<h2 style="font-size:1.75rem;margin-bottom:16px">Curriculum</h2>' +
          modulesHtml +
        '</section>' +
        '<section style="margin-bottom:32px">' +
          '<h2 style="font-size:1.75rem;margin-bottom:16px">Portfolio-ready projects</h2>' +
          projectsHtml +
        '</section>' +
        '<section class="overview-box">' +
          '<h2 style="font-size:1.75rem;margin-bottom:12px">Skill checklist</h2>' +
          '<p style="font-size:14px">Track these as you progress.</p>' +
          '<ul class="checklist">' + subject.skillChecklist.map(s => '<li>' + s + '</li>').join('') + '</ul>' +
        '</section>' +
        '<section class="overview-box">' +
          '<h2 style="font-size:1.75rem;margin-bottom:12px">Recommended next steps</h2>' +
          '<ol style="margin:0;padding-left:20px;color:var(--text-muted);font-size:14px">' +
            '<li>Complete the beginner module and its guided project.</li>' +
            '<li>Attempt independent practice and challenge mode before viewing any solution.</li>' +
            '<li>Package your project with a README and add it to your portfolio.</li>' +
          '</ol>' +
          '<div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">' +
            (hasAssessment ? '<a class="btn btn-primary" href="assessment.html?subject=' + subject.id + '">Take the assessment →</a>' : '') +
            '<a href="explore.html" class="btn btn-secondary">Browse other subjects</a>' +
          '</div>' +
        '</section>' +
      '</div>' +
    '</div>';

  recordSubjectExplored(subject.id);
}

function categoryName(id) {
  return {
    programming: 'Programming',
    data: 'Data Science and Analytics',
    ai: 'Artificial Intelligence',
    finance: 'Finance and Quantitative Skills',
    software: 'Software Development',
  }[id] || id;
}

function cap(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}