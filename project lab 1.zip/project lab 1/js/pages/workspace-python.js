import { PY_EXERCISES, getPyExercise } from '../data/exercises.js';
import { runPython } from '../workspaces/python-runner.js';
import { explainPythonError } from '../workspaces/hints-engine.js';
import { createEditor } from '../workspaces/editor.js';
import { getItemSync, setItemSync, recordExerciseCompleted } from '../store.js';

const root = document.getElementById('root');
const params = new URLSearchParams(location.search);
const initialExerciseId = params.get('exercise') || PY_EXERCISES[0].id;
const initialExercise = getPyExercise(initialExerciseId) || PY_EXERCISES[0];

const state = {
  exercise: initialExercise,
  editor: null,
  running: false,
  lastStatus: '',
  shownHints: 0,
  solutionShown: false,
};

const PROGRESS_KEY = 'workspace_python_progress';

function loadProgress() { return getItemSync(PROGRESS_KEY, { completed: {} }); }
function saveProgress(p) { setItemSync(PROGRESS_KEY, p); }
function isCompleted(id) {
  const p = loadProgress();
  return !!p.completed[id];
}
async function markCompleted(id) {
  const p = loadProgress();
  p.completed[id] = true;
  saveProgress(p);
  try { await recordExerciseCompleted(id); } catch (_) {}
  renderExerciseList();
}

function renderExerciseList() {
  return '<ul class="exercise-list" id="exercise-list">' +
    PY_EXERCISES.map(ex => {
      const active = ex.id === state.exercise.id ? 'active' : '';
      const done = isCompleted(ex.id) ? 'done' : '';
      return '<li data-ex-id="' + ex.id + '" class="' + active + '">' +
        '<div><div class="ex-name">' + esc(ex.title) + '</div><div class="ex-diff">' + ex.difficulty + '</div></div>' +
        '<span class="ex-status ' + done + '">' + (done ? '✓ done' : '') + '</span>' +
        '</li>';
    }).join('') +
    '</ul>';
}

function renderPanel() {
  const ex = state.exercise;
  const hintBtnDisabled = state.shownHints >= ex.hints.length ? ' disabled' : '';
  const hintLabel = state.shownHints === 0
    ? 'Show a hint'
    : 'Show hint ' + (state.shownHints + 1) + ' of ' + ex.hints.length;
  const hintPanel = state.shownHints > 0
    ? '<div class="ws-hint-panel"><strong>Hint ' + state.shownHints + ' of ' + ex.hints.length + '</strong>' +
      esc(ex.hints[state.shownHints - 1]) + '</div>'
    : '';
  const solutionPanel = state.solutionShown
    ? '<div class="ws-solution"><strong>Solution</strong>' +
      '<div class="codeblock" style="margin-top:6px">' + esc(ex.solution) + '</div>' +
      '<p style="margin-top:8px">' + esc(ex.solutionExplanation) + '</p></div>'
    : '';
  return '<aside class="ws-panel" aria-label="Exercises">' +
    '<h2>Python Workspace</h2>' +
    '<p style="font-size:14px">Practice exercises run in-browser using Pyodide. Your code never touches a server.</p>' +
    '<h3 style="margin-top:16px">Exercises</h3>' + renderExerciseList() +
    '<h3>Current exercise</h3>' +
    '<p><strong>' + esc(ex.title) + '</strong></p>' +
    '<p style="font-size:14px"><strong>Objective:</strong> ' + esc(ex.objective) + '</p>' +
    '<p style="font-size:14px;white-space:pre-wrap">' + esc(ex.problem) + '</p>' +
    '<div style="margin-top:16px">' +
      '<button class="btn btn-secondary btn-sm" id="show-hint"' + hintBtnDisabled + '>' + hintLabel + '</button> ' +
      '<button class="btn btn-ghost btn-sm" id="show-solution">' + (state.solutionShown ? 'Hide solution' : 'Reveal solution') + '</button>' +
    '</div>' + hintPanel + solutionPanel +
    '</aside>';
}

function render() {
  const loading = document.querySelector('.workspace-loading');
  if (loading) loading.remove();

  root.innerHTML =
    '<section class="ws-header"><div class="container ws-header-inner">' +
      '<div><h1>Python Workspace</h1><p class="ws-sub">Runs in your browser via Pyodide (WebAssembly Python). First run downloads the runtime.</p></div>' +
      '<span class="ws-badge">Sandboxed · No backend</span>' +
    '</div></section>' +
    '<div class="ws-layout">' +
      '<div id="panel-mount">' + renderPanel() + '</div>' +
      '<div class="ws-main">' +
        '<div class="ws-editor-wrap">' +
          '<div class="ws-editor-toolbar">' +
            '<button class="btn btn-primary btn-sm" id="run-btn">▶ Run</button>' +
            '<button class="btn btn-secondary btn-sm" id="reset-btn">Reset code</button>' +
            '<button class="btn btn-ghost btn-sm" id="check-btn">Check answer</button>' +
            '<span class="spacer"></span>' +
            '<span class="status" id="ws-status">' + esc(state.lastStatus) + '</span>' +
          '</div>' +
          '<div id="editor-mount" style="flex:1"></div>' +
        '</div>' +
        '<div class="ws-console-wrap">' +
          '<div class="ws-console-toolbar"><strong>Console</strong><button class="clear-btn" id="clear-console">Clear</button></div>' +
          '<div class="ws-console" id="ws-console" aria-live="polite"></div>' +
        '</div>' +
      '</div>' +
    '</div>';

  createEditor(document.getElementById('editor-mount'), {
    language: 'python',
    initial: state.exercise.starterCode,
  }).then((editor) => {
    state.editor = editor;
    attachHandlers();
  });
}

function attachHandlers() {
  document.getElementById('run-btn').addEventListener('click', onRun);
  document.getElementById('reset-btn').addEventListener('click', () => {
    state.editor.setValue(state.exercise.starterCode);
    setStatus('Reset to starter code', 'muted');
  });
  document.getElementById('check-btn').addEventListener('click', onCheck);
  document.getElementById('clear-console').addEventListener('click', () => {
    document.getElementById('ws-console').innerHTML = '';
  });
  document.getElementById('show-hint').addEventListener('click', () => {
    state.shownHints = Math.min(state.shownHints + 1, state.exercise.hints.length);
    reRenderPanel();
  });
  document.getElementById('show-solution').addEventListener('click', () => {
    state.solutionShown = !state.solutionShown;
    reRenderPanel();
  });
  document.getElementById('exercise-list').addEventListener('click', (e) => {
    const li = e.target.closest('[data-ex-id]');
    if (!li) return;
    switchExercise(li.dataset.exId);
  });
}

function reRenderPanel() {
  document.getElementById('panel-mount').innerHTML = renderPanel();
  document.getElementById('show-hint').addEventListener('click', () => {
    state.shownHints = Math.min(state.shownHints + 1, state.exercise.hints.length);
    reRenderPanel();
  });
  document.getElementById('show-solution').addEventListener('click', () => {
    state.solutionShown = !state.solutionShown;
    reRenderPanel();
  });
  document.getElementById('exercise-list').addEventListener('click', (e) => {
    const li = e.target.closest('[data-ex-id]');
    if (!li) return;
    switchExercise(li.dataset.exId);
  });
}

function switchExercise(id) {
  const ex = getPyExercise(id);
  if (!ex) return;
  state.exercise = ex;
  state.shownHints = 0;
  state.solutionShown = false;
  if (state.editor) state.editor.setValue(ex.starterCode);
  document.getElementById('ws-console').innerHTML = '';
  setStatus('', '');
  reRenderPanel();
}

async function onRun() {
  if (state.running) return;
  state.running = true;
  setStatus('Running…', 'running');
  appendConsole('> Running…', 'muted');
  const result = await runPython(state.editor.getValue());
  if (result.stdout) appendConsole(result.stdout.replace(/\n$/, ''), '');
  if (result.ok) {
    setStatus('✓ Finished with no errors', 'ok');
  } else {
    appendConsole(result.stderr.split('\n').slice(-15).join('\n'), 'err');
    const hint = explainPythonError(result.stderr);
    appendConsole('', '');
    appendConsole('Hint: ' + hint.title, 'hint');
    appendConsole(hint.fix, 'hint');
    setStatus('✗ Error — see console', 'error');
  }
  state.running = false;
}

async function onCheck() {
  if (state.running) return;
  state.running = true;
  setStatus('Checking…', 'running');
  appendConsole('> Checking answer…', 'muted');
  const result = await runPython(state.editor.getValue());
  if (!result.ok) {
    appendConsole(result.stderr.split('\n').slice(-15).join('\n'), 'err');
    appendConsole('Your code raised an error. Fix that first, then try again.', 'hint');
    setStatus('✗ Error before validation', 'error');
    state.running = false;
    return;
  }
  if (result.stdout) appendConsole(result.stdout.replace(/\n$/, ''), '');
  const passed = state.exercise.validator(result.stdout);
  if (passed) {
    appendConsole('', '');
    appendConsole('✓ Correct — answer validated.', 'ok');
    setStatus('✓ Correct', 'ok');
    await markCompleted(state.exercise.id);
  } else {
    appendConsole('', '');
    appendConsole('✗ Not correct yet. Compare your output to the expected output on the left.', 'err');
    setStatus('✗ Answer does not match', 'error');
  }
  state.running = false;
}

function appendConsole(text, cls) {
  const c = document.getElementById('ws-console');
  const d = document.createElement('div');
  d.className = 'line ' + (cls || '');
  d.textContent = text;
  c.appendChild(d);
  c.scrollTop = c.scrollHeight;
}

function setStatus(text, kind) {
  state.lastStatus = text;
  const el = document.getElementById('ws-status');
  if (!el) return;
  el.textContent = text;
  el.className = 'status ' + (kind || '');
}

function esc(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

render();