import { getProjectById } from '../data/projects.js';
import { getSubjectById } from '../data/subjects.js';
import { getProjectContent } from '../data/project-content.js';
import { recordProjectStarted } from '../store.js';

const root = document.getElementById('root');
const id = new URLSearchParams(location.search).get('id');
const project = getProjectById(id);
const content = getProjectContent(id);

if (!project || !content) {
  root.innerHTML = '<section class="section"><div class="container empty-state"><h2>Project not found</h2><p>This project is not yet in the catalogue, or its content is still being prepared.</p><a href="explore.html" class="btn btn-primary">Browse projects and subjects</a></div></section>';
} else {
  const subject = getSubjectById(project.subjectId);
  document.title = project.title + ' — ProjectLab';

  const stages = [
    { key: 'understand', label: 'Understand' },
    { key: 'guided_project', label: 'Guided Project' },
    { key: 'independent_practice', label: 'Independent Practice' },
    { key: 'challenge_mode', label: 'Challenge Mode' },
    { key: 'advanced_challenge', label: 'Advanced Challenge' },
    { key: 'portfolio_assessment', label: 'Portfolio & Assessment' },
  ];

  const railLinks = stages.map((s, i) =>
    '<li><a href="#stage-' + s.key + '" data-stage="' + s.key + '">' + (i + 1) + '. ' + s.label + '</a></li>'
  ).join('');

  const stageSections = stages.map((s, i) =>
    '<section class="stage-section" id="stage-' + s.key + '" data-stage-key="' + s.key + '">' +
      '<div class="stage-head">' +
        '<span class="stage-badge">Stage ' + (i + 1) + '</span>' +
        '<h2>' + s.label + '</h2>' +
      '</div>' +
      renderStage(s.key, content.stages[s.key], id) +
    '</section>'
  ).join('');

  const downloads = downloadableFilesMarkup(id);

  root.innerHTML =
    '<section class="proj-hero"><div class="container">' +
      '<div class="proj-breadcrumb"><a href="explore.html">Explore</a> / ' +
        (subject ? '<a href="subject.html?id=' + subject.id + '">' + esc(subject.name) + '</a> / ' : '') +
        '<span>' + esc(project.title) + '</span></div>' +
      '<h1>' + esc(project.title) + '</h1>' +
      '<div class="proj-hero-meta">' +
        '<span class="tag tag-level-' + project.difficulty + '">' + cap(project.difficulty) + '</span>' +
        '<span class="tag">' + esc(project.duration) + '</span>' +
        '<span class="tag">' + esc(project.industry) + '</span>' +
        '<span class="tag">6-stage methodology</span>' +
      '</div>' +
      '<p>' + esc(project.blurb) + '</p>' +
    '</div></section>' +
    '<div class="container proj-layout">' +
      '<aside class="stage-rail" aria-label="Project stages">' +
        '<h4>Stages</h4>' +
        '<ol>' + railLinks + '</ol>' +
      '</aside>' +
      '<div>' +
        '<section class="overview-box">' +
          '<h2 style="font-size:1.75rem;margin-bottom:12px">Overview</h2>' +
          '<p>' + esc(content.overview) + '</p>' +
          '<h4 style="margin-top:16px">Prerequisites</h4>' +
          '<ul>' + content.prerequisites.map(p => '<li>' + esc(p) + '</li>').join('') + '</ul>' +
        '</section>' +
        '<section class="overview-box">' +
          '<h2 style="font-size:1.75rem;margin-bottom:12px">Learning objectives</h2>' +
          '<ul>' + content.learningObjectives.map(o => '<li>' + esc(o) + '</li>').join('') + '</ul>' +
        '</section>' +
        '<section class="overview-box">' +
          '<h2 style="font-size:1.75rem;margin-bottom:12px">Dataset &amp; tools</h2>' +
          '<p><strong>Tools:</strong></p>' +
          '<ul>' + content.tools.map(t => '<li>' + esc(t) + '</li>').join('') + '</ul>' +
          '<p style="margin-top:12px"><strong>Dataset:</strong> ' + esc(content.dataset.name) + '</p>' +
          '<div class="callout callout-warn"><strong>Data honesty:</strong> ' + esc(content.dataset.note) + '</div>' +
          downloads +
        '</section>' +
        stageSections +
      '</div>' +
    '</div>';

  wireInteractions();
  attachStageRailObserver();
  recordProjectStarted(project.id);
}

function renderStage(key, data, projectId) {
  if (!data) return '<p>This stage\'s content is being prepared.</p>';
  if (key === 'understand') return renderUnderstand(data);
  if (key === 'guided_project') return renderGuided(data, projectId);
  if (key === 'independent_practice') return renderIndependent(data);
  if (key === 'challenge_mode') return renderChallenge(data);
  if (key === 'advanced_challenge') return renderAdvanced(data);
  if (key === 'portfolio_assessment') return renderPortfolio(data);
  return '';
}

function renderUnderstand(d) {
  return '<p>' + esc(d.intro) + '</p>' +
    '<h3>Core concepts</h3>' +
    d.concepts.map(c =>
      '<div class="info-block"><h4>' + esc(c.term) + '</h4><p>' + esc(c.explanation) + '</p>' +
      (c.example ? '<div class="codeblock">' + esc(c.example) + '</div>' : '') +
      '</div>'
    ).join('') +
    '<h3>Common mistakes</h3>' +
    '<ul>' + d.commonMistakes.map(m => '<li>' + esc(m) + '</li>').join('') + '</ul>' +
    '<h3>Knowledge checks</h3>' +
    d.knowledgeChecks.map((kc, i) =>
      '<div class="info-block"><p><strong>Q' + (i + 1) + '. ' + esc(kc.q) + '</strong></p>' +
      (kc.options ? '<ol style="padding-left:20px">' + kc.options.map(o => '<li>' + esc(o) + '</li>').join('') + '</ol>' : '') +
      '<button class="hint-btn" data-toggle-next>Reveal answer</button>' +
      '<div class="hint-content"><p><strong>Answer:</strong> ' + (kc.options ? esc(kc.options[kc.answer]) : 'See explanation') + '</p><p>' + esc(kc.explanation) + '</p></div>' +
      '</div>'
    ).join('');
}

function renderGuided(d, projectId) {
  return '<p>' + esc(d.intro) + '</p>' +
    d.steps.map((step, i) =>
      '<article class="guided-step">' +
        '<div class="guided-step-head"><div><span class="guided-step-num">Step ' + (i + 1) + '</span><h3>' + esc(step.title) + '</h3></div></div>' +
        '<dl class="guided-meta">' +
          '<dt>Why it matters</dt><dd>' + esc(step.why) + '</dd>' +
          '<dt>Concept</dt><dd>' + esc(step.concept) + '</dd>' +
        '</dl>' +
        '<h4>Instructions</h4>' +
        '<ol>' + step.instructions.map(x => '<li>' + esc(x) + '</li>').join('') + '</ol>' +
        (step.code ? '<div class="codeblock">' + esc(step.code) + '</div>' : '') +
        (step.codeExplanation ? '<p><em>' + esc(step.codeExplanation) + '</em></p>' : '') +
        (step.expectedOutput ? '<h4>Expected output</h4><div class="output-block">' + esc(step.expectedOutput) + '</div>' : '') +
        (step.commonErrors && step.commonErrors.length ? '<h4>Common errors</h4><ul>' + step.commonErrors.map(e => '<li>' + esc(e) + '</li>').join('') + '</ul>' : '') +
        (step.troubleshooting ? '<div class="callout callout-info"><strong>Troubleshooting:</strong> ' + esc(step.troubleshooting) + '</div>' : '') +
        (step.checkpoint ? '<div class="checkpoint">' + esc(step.checkpoint) + '</div>' : '') +
        workspaceButtonFor(projectId, step) +
      '</article>'
    ).join('');
}

function renderIndependent(d) {
  return '<h3>Problem statement</h3><p>' + esc(d.problem) + '</p>' +
    '<h3>Starter</h3><p>' + esc(d.starter) + '</p>' +
    '<h3>Deliverable</h3><ul>' + d.deliverable.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' +
    '<h3>Evaluation criteria</h3><ul>' + d.evaluationCriteria.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' +
    '<div class="callout callout-info"><strong>No solution provided.</strong> Solve this independently.</div>';
}

function renderChallenge(d) {
  return '<h3>Problem</h3><p>' + esc(d.problem) + '</p>' +
    '<h3>Progressive hints</h3><p>Try the problem first, then reveal hints.</p>' +
    d.hints.map((h, i) =>
      '<div class="hint-group"><button class="hint-btn" data-toggle-next>Hint ' + (i + 1) + '</button><div class="hint-content"><p>' + esc(h) + '</p></div></div>'
    ).join('') +
    '<div class="solution-wrap">' +
      '<button class="solution-toggle" data-reveal-solution>Reveal full solution</button>' +
      '<div class="solution-body"><h4>Solution</h4><div class="codeblock">' + esc(d.solution) + '</div><h4>Explanation</h4><p>' + esc(d.solutionExplanation) + '</p></div>' +
    '</div>';
}

function renderAdvanced(d) {
  return '<h3>Problem</h3><p>' + esc(d.problem) + '</p>' +
    '<h3>Business context</h3><p>' + esc(d.businessContext) + '</p>' +
    '<h3>Constraints</h3><ul>' + d.constraints.map(c => '<li>' + esc(c) + '</li>').join('') + '</ul>' +
    '<h3>Deliverable</h3><ul>' + d.deliverable.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' +
    '<h3>Trade-offs</h3><ul>' + d.tradeOffs.map(t => '<li>' + esc(t) + '</li>').join('') + '</ul>';
}

function renderPortfolio(d) {
  return '<h3>Final deliverable</h3><p>' + esc(d.deliverable) + '</p>' +
    '<h3>README contents</h3><ul>' + d.readmePoints.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' +
    '<h3>Skills demonstrated</h3><ul>' + d.skillsDemonstrated.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' +
    '<h3>Business interpretation</h3><p>' + esc(d.businessInterpretation) + '</p>' +
    '<h3>Interview questions</h3><ul class="interview-qs">' + d.interviewQuestions.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' +
    '<h3>Suggested improvements</h3><ul>' + d.improvements.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' +
    '<h3>Assessment rubric</h3>' +
    '<table class="rubric-table"><thead><tr><th>Criterion</th><th>Weight</th><th>Description</th></tr></thead><tbody>' +
    d.rubric.map(r => '<tr><td><strong>' + esc(r.criterion) + '</strong></td><td>' + r.weight + '%</td><td>' + esc(r.description) + '</td></tr>').join('') +
    '<tr><td colspan="2"><strong>Total</strong></td><td>' + d.rubric.reduce((s, r) => s + r.weight, 0) + '%</td></tr>' +
    '</tbody></table>' +
    '<div class="callout callout-success" style="margin-top:16px"><strong>Downloading your work:</strong> export your code, README and dataset alongside this rubric. The portfolio page lets you record completion and download a README.</div>';
}

function downloadableFilesMarkup(projectId) {
  const map = {
    'personal-expense-tracker': [
      { href: 'assets/datasets/expenses_sample.csv', label: 'expenses_sample.csv', meta: 'Synthetic sample' },
      { href: 'assets/datasets/README.md', label: 'Dataset notes', meta: 'Data honesty notice' },
    ],
    'retail-database-analysis': [
      { href: 'assets/datasets/retail_sample.sql', label: 'retail_sample.sql', meta: 'Synthetic schema' },
      { href: 'assets/datasets/README.md', label: 'Dataset notes', meta: 'Data honesty notice' },
    ],
    'sales-performance-dashboard': [
      { href: 'assets/datasets/sales_sample.csv', label: 'sales_sample.csv', meta: 'Synthetic' },
    ],
    'house-price-prediction': [
      { href: 'assets/datasets/housing_sample.csv', label: 'housing_sample.csv', meta: 'Synthetic' },
    ],
    'financial-statement-analysis': [
      { href: 'assets/datasets/statements_sample.csv', label: 'statements_sample.csv', meta: 'Synthetic' },
    ],
    'customer-churn-prediction': [
      { href: 'assets/datasets/churn_sample.csv', label: 'churn_sample.csv', meta: 'Synthetic' },
    ],
  };
  const files = map[projectId] || [];
  if (!files.length) return '';
  return '<h4 style="margin-top:16px">Starter files</h4><div class="file-list">' +
    files.map(f => '<a href="' + f.href + '" download><span>' + esc(f.label) + '</span><span class="file-meta">' + esc(f.meta) + ' ↓</span></a>').join('') +
    '</div>';
}

function workspaceButtonFor(projectId, step) {
  const map = {
    'personal-expense-tracker': { url: 'workspace-python.html', label: 'Open Python workspace', exercise: 'py-sum-list' },
    'retail-database-analysis': { url: 'workspace-sql.html', label: 'Open SQL workspace', exercise: 'sql-count-customers' },
  };
  const t = map[projectId];
  if (!t || !step.code) return '';
  return '<div style="margin-top:12px"><a class="btn btn-primary btn-sm" href="' + t.url + '?exercise=' + t.exercise + '">' + t.label + ' →</a></div>';
}

function wireInteractions() {
  root.querySelectorAll('[data-toggle-next]').forEach(btn => {
    btn.addEventListener('click', () => {
      const c = btn.nextElementSibling;
      if (!c || !c.classList.contains('hint-content')) return;
      c.classList.toggle('open');
      const open = c.classList.contains('open');
      let label = btn.textContent;
      if (label.indexOf('Reveal answer') >= 0) label = open ? 'Hide answer' : 'Reveal answer';
      else if (label.indexOf('Hide answer') >= 0) label = open ? 'Hide answer' : 'Reveal answer';
      else if (label.indexOf('Hide hint') >= 0) label = open ? 'Hide hint' : label.replace('Hide hint', 'Hint');
      else label = open ? label.replace('Hint', 'Hide hint') : label;
      btn.textContent = label;
    });
  });
  root.querySelectorAll('[data-reveal-solution]').forEach(btn => {
    btn.addEventListener('click', () => {
      const b = btn.nextElementSibling;
      if (!b) return;
      b.classList.toggle('open');
      btn.textContent = b.classList.contains('open') ? 'Hide solution' : 'Reveal full solution';
    });
  });
}

function attachStageRailObserver() {
  const links = root.querySelectorAll('.stage-rail a[data-stage]');
  const sections = root.querySelectorAll('.stage-section');
  if (!('IntersectionObserver' in window)) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(en => {
      if (en.isIntersecting) {
        const key = en.target.dataset.stageKey;
        links.forEach(l => l.classList.toggle('active', l.dataset.stage === key));
      }
    });
  }, { rootMargin: '-30% 0px -60% 0px' });
  sections.forEach(s => obs.observe(s));
}

function esc(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function cap(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}