import { getAssessment } from '../data/assessments.js';
import { getSubjectById } from '../data/subjects.js';
import { recordAssessment } from '../store.js';

const root = document.getElementById('root');
const params = new URLSearchParams(location.search);
const subjectId = params.get('subject');
const assessment = getAssessment(subjectId);
const subject = getSubjectById(subjectId);

if (!assessment) {
  root.innerHTML = '<section class="section"><div class="container empty-state"><h2>No assessment for this subject</h2><p>Assessments are currently available for: Python, SQL.</p><a href="explore.html" class="btn btn-primary">Browse subjects</a></div></section>';
} else {
  const state = { answers: {}, submitted: false, result: null };
  render();

  function render() {
    document.title = assessment.title + ' — ProjectLab';
    const subjectName = subject ? subject.name : subjectId;
    const questionsHtml = assessment.questions.map((q, i) => renderQuestion(q, i)).join('');
    const resultHtml = state.result ? renderResult(state.result) : '';
    const passPct = Math.round(assessment.passingScore * 100);
    root.innerHTML =
      '<section class="section"><div class="container" style="max-width:820px">' +
        '<nav style="font-size:14px;color:var(--text-faint);margin-bottom:12px">' +
          '<a href="subject.html?id=' + subjectId + '">' + subjectName + '</a> / Assessment</nav>' +
        '<h1>' + esc(assessment.title) + '</h1>' +
        '<p>Answer every question. Multiple-choice and short answers are auto-scored; interpretation questions are self-assessed with a reference answer. Passing score: ' + passPct + '%.</p>' +
        '<form id="quiz-form" style="margin-top:24px">' +
          questionsHtml +
          '<div style="margin-top:24px;display:flex;gap:8px;flex-wrap:wrap">' +
            '<button type="submit" class="btn btn-primary"' + (state.submitted ? ' disabled' : '') + '>Submit answers</button>' +
            (state.submitted ? '<a class="btn btn-secondary" href="dashboard.html">Go to dashboard</a>' : '') +
          '</div>' +
        '</form>' +
        resultHtml +
      '</div></section>';
    if (!state.submitted) attachForm();
  }

  function renderQuestion(q, i) {
    const val = state.answers[q.id];
    if (q.type === 'mc') {
      const opts = q.options.map((o, idx) =>
        '<label style="display:block;padding:6px 0">' +
          '<input type="radio" name="' + q.id + '" value="' + idx + '"' + (val === idx ? ' checked' : '') + (state.submitted ? ' disabled' : '') + ' /> ' +
          esc(o) +
        '</label>'
      ).join('');
      return '<div class="info-block"><p><strong>Q' + (i + 1) + '. ' + esc(q.question) + '</strong></p>' + opts + (state.submitted ? renderFeedback(q, val) : '') + '</div>';
    }
    if (q.type === 'short') {
      return '<div class="info-block"><p><strong>Q' + (i + 1) + '. ' + esc(q.question) + '</strong></p>' +
        '<input class="input" type="text" name="' + q.id + '" value="' + esc(val || '') + '"' + (state.submitted ? ' disabled' : '') + ' />' +
        (state.submitted ? renderFeedback(q, val) : '') +
        '</div>';
    }
    return '<div class="info-block"><p><strong>Q' + (i + 1) + '. ' + esc(q.question) + '</strong></p>' +
      '<textarea class="input" name="' + q.id + '" rows="3"' + (state.submitted ? ' disabled' : '') + '>' + esc(val || '') + '</textarea>' +
      (state.submitted ? renderFeedback(q, val) : '') +
      '</div>';
  }

  function renderFeedback(q, val) {
    if (q.type === 'mc') {
      const correct = val === q.answer;
      return '<div class="callout ' + (correct ? 'callout-success' : 'callout-warn') + '" style="margin-top:8px">' +
        '<strong>' + (correct ? '✓ Correct' : '✗ Not quite') + '</strong> — answer is: ' + esc(q.options[q.answer]) +
        '<br>' + esc(q.explanation) + '</div>';
    }
    if (q.type === 'short') {
      const norm = String(val || '').trim().replace(/\s+/g, ' ').toLowerCase();
      const correct = q.accept.some(a => a.toLowerCase() === norm);
      return '<div class="callout ' + (correct ? 'callout-success' : 'callout-warn') + '" style="margin-top:8px">' +
        '<strong>' + (correct ? '✓ Correct' : '✗ Not quite') + '</strong> — expected: ' + esc(q.accept[0]) +
        '<br>' + esc(q.explanation) + '</div>';
    }
    return '<div class="callout callout-info" style="margin-top:8px">' +
      '<strong>Reference answer (self-assess)</strong>' +
      '<p style="margin:8px 0 0">' + esc(q.reference) + '</p></div>';
  }

  function renderResult(r) {
    const pct = Math.round((r.score / r.total) * 100);
    const weak = r.weakAreas && r.weakAreas.length
      ? '<h3 style="margin-top:16px">Areas to review</h3><ul>' + r.weakAreas.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>'
      : '';
    return '<div class="overview-box" style="margin-top:24px">' +
      '<h2 style="font-size:1.75rem;margin-bottom:12px">Result</h2>' +
      '<p><strong>Score: ' + r.score + ' / ' + r.total + '</strong> (' + pct + '%)</p>' +
      '<p>' + (r.passed ? '✓ Passed.' : 'Below the passing score. Review the questions you missed, then try again.') + '</p>' +
      weak +
      '</div>';
  }

  function attachForm() {
    const form = document.getElementById('quiz-form');
    if (!form) return;
    form.addEventListener('change', (e) => {
      if (e.target.name) {
        state.answers[e.target.name] = e.target.type === 'radio' ? Number(e.target.value) : e.target.value;
      }
    });
    form.addEventListener('input', (e) => {
      if (e.target.name && e.target.type !== 'radio') {
        state.answers[e.target.name] = e.target.value;
      }
    });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      for (const q of assessment.questions) {
        if (q.type === 'mc') {
          const el = form.querySelector('input[name="' + q.id + '"]:checked');
          if (el) state.answers[q.id] = Number(el.value);
        } else {
          const el = form.querySelector('[name="' + q.id + '"]');
          if (el) state.answers[q.id] = el.value;
        }
      }
      const result = scoreAssessment(assessment, state.answers);
      state.submitted = true;
      state.result = result;
      await recordAssessment(subjectId, { score: result.score, total: result.total, answers: state.answers });
      render();
    });
  }
}

function scoreAssessment(a, answers) {
  let score = 0;
  const weakAreas = [];
  for (const q of a.questions) {
    const v = answers[q.id];
    if (q.type === 'mc') {
      if (v === q.answer) score += 1;
      else weakAreas.push(q.question);
    } else if (q.type === 'short') {
      const norm = String(v || '').trim().replace(/\s+/g, ' ').toLowerCase();
      if (q.accept.some(x => x.toLowerCase() === norm)) score += 1;
      else weakAreas.push(q.question);
    } else {
      if (String(v || '').trim().length > 20) score += 1;
      else weakAreas.push(q.question);
    }
  }
  const total = a.questions.length;
  return { score, total, passed: score / total >= a.passingScore, weakAreas };
}

function esc(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}