import { SQL_EXERCISES, getSqlExercise } from '../data/exercises.js';
import { initSql, resetToSeed, runSql, getSchema } from '../workspaces/sql-runner.js';
import { explainSqlError } from '../workspaces/hints-engine.js';
import { createEditor } from '../workspaces/editor.js';
import { getItemSync, setItemSync, recordExerciseCompleted } from '../store.js';

const root = document.getElementById('root');
const params = new URLSearchParams(location.search);
const initialExerciseId = params.get('exercise') || SQL_EXERCISES[0].id;
const initialExercise = getSqlExercise(initialExerciseId) || SQL_EXERCISES[0];

const state = {
  exercise: initialExercise,
  editor: null,
  running: false,
  lastStatus: '',
  shownHints: 0,
  solutionShown: false,
};

const PROGRESS_KEY = 'workspace_sql_progress';

function loadProgress() { return getItemSync(PROGRESS_KEY, { completed: {} }); }
function saveProgress(p) { setItemSync(PROGRESS_KEY, p); }
function isCompleted(id) {
  const p = loadProgress();
  return !!p.completed[id];
}
async function markCompleted(id) {
  const p = loadProgress();
  p.completed[id] = true;
  saveProgress(p);
  try { await recordExerciseCompleted(id); } catch (_) {}
}

async function loadSeed() {
  const res = await fetch('assets/datasets/retail_sample.sql');
  if (!res.ok) throw new Error('Could not load retail_sample.sql');
  return await res.text();
}

async function boot() {
  try {
    const seed = await loadSeed();
    await initSql(seed);
    render();
  } catch (err) {
    root.innerHTML = '<section class="section"><div class="container empty-state">' +
      '<h2>Could not load SQL workspace</h2>' +
      '<p>' + esc(err.message) + '</p>' +
      '<p>Check your internet connection (the SQLite WASM runtime is loaded from a CDN).</p>' +
      '</div></section>';
  }
}

function renderExerciseList() {
  return '<ul class="exercise-list" id="exercise-list">' +
    SQL_EXERCISES.map(ex => {
      const active = ex.id === state.exercise.id ? 'active' : '';
      const done = isCompleted(ex.id) ? 'done' : '';
      return '<li data-ex-id="' + ex.id + '" class="' + active + '">' +
        '<div><div class="ex-name">' + esc(ex.title) + '</div><div class="ex-diff">' + ex.difficulty + '</div></div>' +
        '<span class="ex-status ' + done + '">' + (done ? '✓ done' : '') + '</span>' +
        '</li>';
    }).join('') +
    '</ul>';
}

function renderSchema() {
  const schema = getSchema();
  if (!schema.length) return '<p class="sql-msg">No tables.</p>';
  return schema.map(t =>
    '<details class="schema-table"><summary>' + esc(t.name) + '</summary>' +
    '<ul class="schema-cols">' +
    t.columns.map(c =>
      '<li>' + esc(c.name) +
      '<span class="col-type">' + esc(c.type || '') + '</span>' +
      (c.primaryKey ? '<span class="col-pk">PK</span>' : '') +
      '</li>'
    ).join('') +
    '</ul></details>'
  ).join('');
}

function renderPanel() {
  const ex = state.exercise;
  const hintBtnDisabled = state.shownHints >= ex.hints.length ? ' disabled' : '';
  const hintLabel = state.shownHints === 0
    ? 'Show a hint'
    : 'Show hint ' + (state.shownHints + 1) + ' of ' + ex.hints.length;
  const hintPanel = state.shownHints > 0
    ? '<div class="ws-hint-panel"><strong>Hint ' + state.shownHints + ' of ' + ex.hints.length + '</strong>' +
      esc(ex.hints[state.shownHints - 1]) + '</div>'
    : '';
  const solutionPanel = state.solutionShown
    ? '<div class="ws-solution"><strong>Solution</strong>' +
      '<div class="codeblock" style="margin-top:6px">' + esc(ex.solution) + '</div>' +
      '<p style="margin-top:8px">' + esc(ex.solutionExplanation) + '</p></div>'
    : '';
  return '<aside class="ws-panel ws-sql-sidebar" aria-label="Exercises and schema">' +
    '<h2>SQL Workspace</h2>' +
    '<p style="font-size:14px">Runs SQLite in your browser via sql.js. Your queries never leave this tab.</p>' +
    '<h3>Schema</h3>' +
    '<div id="schema-mount">' + renderSchema() + '</div>' +
    '<h3 style="margin-top:16px">Exercises</h3>' + renderExerciseList() +
    '<h3>Current exercise</h3>' +
    '<p><strong>' + esc(ex.title) + '</strong></p>' +
    '<p style="font-size:14px"><strong>Objective:</strong> ' + esc(ex.objective) + '</p>' +
    '<p style="font-size:14px;white-space:pre-wrap">' + esc(ex.problem) + '</p>' +
    '<div style="margin-top:16px">' +
      '<button class="btn btn-secondary btn-sm" id="show-hint"' + hintBtnDisabled + '>' + hintLabel + '</button> ' +
      '<button class="btn btn-ghost btn-sm" id="show-solution">' + (state.solutionShown ? 'Hide solution' : 'Reveal solution') + '</button>' +
    '</div>' + hintPanel + solutionPanel +
    '</aside>';
}

function render() {
  const loading = document.querySelector('.workspace-loading');
  if (loading) loading.remove();

  root.innerHTML =
    '<section class="ws-header"><div class="container ws-header-inner">' +
      '<div><h1>SQL Workspace</h1><p class="ws-sub">SQLite runs entirely in your browser via WebAssembly. The sample retail database is loaded for you.</p></div>' +
      '<span class="ws-badge">Sandboxed · No backend</span>' +
    '</div></section>' +
    '<div class="ws-layout">' +
      '<div id="panel-mount">' + renderPanel() + '</div>' +
      '<div class="ws-main">' +
        '<div class="ws-editor-wrap">' +
          '<div class="ws-editor-toolbar">' +
            '<button class="btn btn-primary btn-sm" id="run-btn">▶ Run query</button>' +
            '<button class="btn btn-secondary btn-sm" id="reset-btn">Reset code</button>' +
            '<button class="btn btn-ghost btn-sm" id="reset-db-btn">Reset database</button>' +
            '<button class="btn btn-ghost btn-sm" id="check-btn">Check answer</button>' +
            '<span class="spacer"></span>' +
            '<span class="status" id="ws-status">' + esc(state.lastStatus) + '</span>' +
          '</div>' +
          '<div id="editor-mount" style="flex:1"></div>' +
        '</div>' +
        '<div class="sql-results-wrap">' +
          '<div class="ws-console-toolbar"><strong>Results</strong><button class="clear-btn" id="clear-results">Clear</button></div>' +
          '<div class="sql-results-meta" id="sql-meta"></div>' +
          '<div class="sql-results-table-wrap" id="sql-results"></div>' +
        '</div>' +
      '</div>' +
    '</div>';

  createEditor(document.getElementById('editor-mount'), {
    language: 'sql',
    initial: state.exercise.starterSql,
  }).then((editor) => {
    state.editor = editor;
    attachHandlers();
  });
}

function attachHandlers() {
  document.getElementById('run-btn').addEventListener('click', () => exec(false));
  document.getElementById('check-btn').addEventListener('click', () => exec(true));
  document.getElementById('reset-btn').addEventListener('click', () => {
    state.editor.setValue(state.exercise.starterSql);
    setStatus('Reset to starter SQL', 'muted');
  });
  document.getElementById('reset-db-btn').addEventListener('click', () => {
    try {
      resetToSeed();
      renderSchemaPanel();
      showResultsMessage('Database reset to the original sample.', 'ok');
      setStatus('Database reset', 'ok');
    } catch (err) {
      showResultsMessage('Reset failed: ' + err.message, 'error');
    }
  });
  document.getElementById('clear-results').addEventListener('click', () => {
    document.getElementById('sql-results').innerHTML = '';
    document.getElementById('sql-meta').textContent = '';
  });
  document.getElementById('show-hint').addEventListener('click', () => {
    state.shownHints = Math.min(state.shownHints + 1, state.exercise.hints.length);
    reRenderPanel();
  });
  document.getElementById('show-solution').addEventListener('click', () => {
    state.solutionShown = !state.solutionShown;
    reRenderPanel();
  });
  document.getElementById('exercise-list').addEventListener('click', (e) => {
    const li = e.target.closest('[data-ex-id]');
    if (!li) return;
    switchExercise(li.dataset.exId);
  });
}

function reRenderPanel() {
  document.getElementById('panel-mount').innerHTML = renderPanel();
  document.getElementById('show-hint').addEventListener('click', () => {
    state.shownHints = Math.min(state.shownHints + 1, state.exercise.hints.length);
    reRenderPanel();
  });
  document.getElementById('show-solution').addEventListener('click', () => {
    state.solutionShown = !state.solutionShown;
    reRenderPanel();
  });
  document.getElementById('exercise-list').addEventListener('click', (e) => {
    const li = e.target.closest('[data-ex-id]');
    if (!li) return;
    switchExercise(li.dataset.exId);
  });
}

function renderSchemaPanel() {
  const m = document.getElementById('schema-mount');
  if (m) m.innerHTML = renderSchema();
}

function switchExercise(id) {
  const ex = getSqlExercise(id);
  if (!ex) return;
  state.exercise = ex;
  state.shownHints = 0;
  state.solutionShown = false;
  if (state.editor) state.editor.setValue(ex.starterSql);
  document.getElementById('sql-results').innerHTML = '';
  document.getElementById('sql-meta').textContent = '';
  setStatus('', '');
  reRenderPanel();
}

function exec(validate) {
  const sql = state.editor.getValue().trim();
  if (!sql) { setStatus('Nothing to run', 'muted'); return; }
  try {
    const result = runSql(sql);
    if (result.isSelect) {
      showResultsTable(result.columns, result.rows);
      document.getElementById('sql-meta').textContent = result.rows.length + ' row' + (result.rows.length === 1 ? '' : 's');
    } else {
      document.getElementById('sql-results').innerHTML = '';
      showResultsMessage('Statement executed. Rows modified: ' + result.changes, 'ok');
      renderSchemaPanel();
    }
    setStatus('✓ Query executed', 'ok');
    if (validate) {
      const v = state.exercise.validator(result.rows);
      if (v.ok) {
        showResultsMessage(v.message, 'ok');
        setStatus('✓ Correct', 'ok');
        markCompleted(state.exercise.id).then(() => reRenderPanel());
      } else {
        showResultsMessage(v.message, 'error');
        setStatus('✗ Answer does not match', 'error');
      }
    }
  } catch (err) {
    const message = err.message || String(err);
    document.getElementById('sql-results').innerHTML = '';
    showResultsMessage(message, 'error');
    const hint = explainSqlError(message);
    showResultsMessage('Hint: ' + hint.title + ' ' + hint.fix, 'error');
    setStatus('✗ SQL error', 'error');
  }
}

function showResultsTable(columns, rows) {
  const el = document.getElementById('sql-results');
  if (!rows.length) { el.innerHTML = '<p class="sql-msg">Query returned no rows.</p>'; return; }
  const head = '<tr>' + columns.map(c => '<th>' + esc(c) + '</th>').join('') + '</tr>';
  const body = rows.map(r =>
    '<tr>' + columns.map(c => '<td>' + esc(String(r[c] == null ? '' : r[c])) + '</td>').join('') + '</tr>'
  ).join('');
  el.innerHTML = '<table class="sql-results-table"><thead>' + head + '</thead><tbody>' + body + '</tbody></table>';
}

function showResultsMessage(text, kind) {
  const el = document.getElementById('sql-results');
  const d = document.createElement('div');
  d.className = 'sql-msg ' + (kind || '');
  d.textContent = text;
  el.appendChild(d);
}

function setStatus(text, kind) {
  state.lastStatus = text;
  const el = document.getElementById('ws-status');
  if (!el) return;
  el.textContent = text;
  el.className = 'status ' + (kind || '');
}

function esc(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

boot();