import { SUBJECTS } from '../data/subjects.js';
import { getFeaturedProjects } from '../data/projects.js';
import { pathCard, projectCard } from '../components/cards.js';

const FEATURED_IDS = ['python', 'sql', 'machine-learning', 'data-analytics'];
const featured = FEATURED_IDS
  .map(id => SUBJECTS.find(s => s.id === id))
  .filter(Boolean);

const pathsMount = document.getElementById('featured-paths');
if (pathsMount) {
  pathsMount.innerHTML = featured.map(pathCard).join('');
  pathsMount.addEventListener('click', (e) => {
    const card = e.target.closest('[data-subject-id]');
    if (!card) return;
    if (e.target.closest('a')) return;
    location.href = 'subject.html?id=' + card.dataset.subjectId;
  });
}

const projectsMount = document.getElementById('featured-projects');
if (projectsMount) {
  projectsMount.innerHTML = getFeaturedProjects(3).map(projectCard).join('');
}

const heroForm = document.getElementById('hero-search-form');
if (heroForm) {
  heroForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.getElementById('hero-search-input');
    const q = input.value.trim();
    location.href = q ? 'explore.html?q=' + encodeURIComponent(q) : 'explore.html';
  });
}