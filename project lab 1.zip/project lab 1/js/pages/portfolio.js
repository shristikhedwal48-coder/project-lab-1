import { getProgress, completeProject } from '../store.js';
import { getProjectById } from '../data/projects.js';
import { getProjectContent } from '../data/project-content.js';

const root = document.getElementById('root');

(async function boot() {
  const p = await getProgress();
  render(p);
})();

function render(p) {
  const started = Object.entries(p.projectsStarted || {});
  const completed = Object.entries(p.projectsCompleted || {});
  document.title = 'Portfolio — ProjectLab';

  const inProgressHtml = started.filter(([id]) => !completed.find(([cid]) => cid === id)).length
    ? '<div class="grid grid-3">' + started.filter(([id]) => !completed.find(([cid]) => cid === id)).map(([id, meta]) => {
        const proj = getProjectById(id);
        if (!proj) return '';
        return '<div class="card">' +
          '<h3 style="margin:0">' + esc(proj.title) + '</h3>' +
          '<p style="font-size:14px;color:var(--text-muted)">Started ' + new Date(meta.startedAt).toLocaleDateString() + '</p>' +
          '<a class="link-arrow" href="project.html?id=' + id + '">Open project →</a>' +
          '</div>';
      }).join('') + '</div>'
    : '<p style="color:var(--text-muted)">No projects in progress. <a href="explore.html">Find a project →</a></p>';

  const completedHtml = completed.length
    ? renderCompleted(completed)
    : '<div class="overview-box"><p style="margin:0;color:var(--text-muted)">No completed projects yet.</p>' +
      '<p style="margin:8px 0 0;font-size:14px">To mark a project complete you need to submit skills and an outcome.</p></div>';

  const projectOptions = Object.keys({
    'personal-expense-tracker': 1,
    'retail-database-analysis': 1,
    'sales-performance-dashboard': 1,
    'house-price-prediction': 1,
    'financial-statement-analysis': 1,
    'customer-churn-prediction': 1,
  }).map(id => {
    const proj = getProjectById(id);
    return proj ? '<option value="' + id + '">' + esc(proj.title) + '</option>' : '';
  }).join('');

  root.innerHTML =
    '<section class="section" style="padding-top:32px"><div class="container">' +
      '<h1>Your Portfolio</h1>' +
      '<p style="max-width:660px">Every completed project becomes a portfolio entry. Each entry records the skills you demonstrated and can be exported as a professional README.</p>' +
      '<h2 style="margin-top:24px">In progress</h2>' + inProgressHtml +
      '<h2 style="margin-top:32px">Completed projects</h2>' + completedHtml +
      '<h2 style="margin-top:32px">Mark a project as completed</h2>' +
      '<div class="overview-box">' +
        '<form id="portfolio-form" class="grid" style="gap:12px;max-width:640px">' +
          '<div><label for="pf-project" style="font-size:14px;font-weight:600">Project</label>' +
            '<select id="pf-project" name="projectId" class="input" required>' +
              '<option value="">— choose —</option>' + projectOptions +
            '</select></div>' +
          '<div><label for="pf-skills" style="font-size:14px;font-weight:600">Skills demonstrated (comma separated)</label>' +
            '<input class="input" id="pf-skills" name="skills" required placeholder="e.g. Python, CSV parsing, dict aggregation"></div>' +
          '<div><label for="pf-outcome" style="font-size:14px;font-weight:600">Outcome / notes</label>' +
            '<textarea class="input" id="pf-outcome" name="outcome" rows="3" required placeholder="What did you build? What did you learn?"></textarea></div>' +
          '<div><label for="pf-github" style="font-size:14px;font-weight:600">Repo link (optional)</label>' +
            '<input class="input" id="pf-github" name="github" placeholder="https://github.com/…"></div>' +
          '<button class="btn btn-primary" type="submit">Mark as completed &amp; add to portfolio</button>' +
        '</form>' +
      '</div>' +
    '</div></section>';

  attachForm();
  attachExportHandlers();
}

function renderCompleted(entries) {
  return '<div class="grid grid-2">' + entries.map(([id, entry]) => {
    const proj = getProjectById(id);
    if (!proj) return '';
    const skills = (entry.skills || []).join(', ') || '—';
    const github = entry.github
      ? '<p style="font-size:14px"><strong>Repo:</strong> <a href="' + esc(entry.github) + '" target="_blank" rel="noopener">' + esc(entry.github) + '</a></p>'
      : '';
    return '<div class="card">' +
      '<h3 style="margin:0">' + esc(proj.title) + '</h3>' +
      '<p style="font-size:14px;color:var(--text-muted);margin:4px 0">Completed ' + new Date(entry.completedAt).toLocaleDateString() + '</p>' +
      '<p style="font-size:14px"><strong>Skills:</strong> ' + esc(skills) + '</p>' +
      '<p style="font-size:14px"><strong>Outcome:</strong> ' + esc(entry.outcome || '—') + '</p>' +
      github +
      '<div style="margin-top:12px"><button class="btn btn-secondary btn-sm" data-export-readme="' + id + '">Download README.md</button></div>' +
      '</div>';
  }).join('') + '</div>';
}

function attachForm() {
  const form = document.getElementById('portfolio-form');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const projectId = data.get('projectId');
    const skills = String(data.get('skills') || '').split(',').map(s => s.trim()).filter(Boolean);
    const outcome = String(data.get('outcome') || '').trim();
    const github = String(data.get('github') || '').trim();
    if (!projectId || skills.length === 0 || outcome.length < 5) {
      alert('Please choose a project, list at least one skill, and describe your outcome.');
      return;
    }
    await completeProject(projectId, { completedAt: Date.now(), skills, outcome, github });
    const p = await getProgress();
    render(p);
  });
}

function attachExportHandlers() {
  document.querySelectorAll('[data-export-readme]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.exportReadme;
      const p = await getProgress();
      const entry = p.projectsCompleted[id];
      downloadFile(id + '-README.md', generateReadme(id, entry), 'text/markdown');
    });
  });
}

function generateReadme(projectId, entry) {
  const proj = getProjectById(projectId);
  const content = getProjectContent(projectId);
  const objectives = (content && content.learningObjectives) || proj.objectives || [];
  const tools = (content && content.tools) || proj.tools || [];
  const improvements = (content && content.stages && content.stages.portfolio_assessment && content.stages.portfolio_assessment.improvements) || [];
  const business = (content && content.stages && content.stages.portfolio_assessment && content.stages.portfolio_assessment.businessInterpretation) || 'See project documentation.';
  const ctx = (content && content.stages && content.stages.advanced_challenge && content.stages.advanced_challenge.businessContext) || 'See project documentation.';
  const datasetName = (content && content.dataset && content.dataset.name) || 'Dataset described in project files.';
  const datasetNote = (content && content.dataset && content.dataset.note) || '';

  const date = new Date().toISOString().slice(0, 10);
  const skills = (entry.skills || []).join(', ');

  return '# ' + proj.title + '\n\n' +
    '*Part of my ProjectLab portfolio.*\n\n' +
    '## Problem statement\n' + ((content && content.overview) || proj.blurb) + '\n\n' +
    '## Business context\n' + ctx + '\n\n' +
    '## Objectives\n' + objectives.map(o => '- ' + o).join('\n') + '\n\n' +
    '## Technologies used\n' + tools.map(t => '- ' + t).join('\n') + '\n\n' +
    '## Dataset description\n' + datasetName + '\n' + (datasetNote ? '\n*' + datasetNote + '*\n' : '') + '\n' +
    '## Methodology\nFollowed the ProjectLab six-stage methodology.\n\n' +
    '## Implementation\n' + (entry.outcome || 'See project files.') + '\n\n' +
    '## Results\n' + (entry.outcome || 'Described above.') + '\n\n' +
    '## Business interpretation\n' + business + '\n\n' +
    '## Challenges encountered\nSee implementation notes above.\n\n' +
    '## Skills demonstrated\n' + skills + '\n\n' +
    (entry.github ? '## Repository\n' + entry.github + '\n\n' : '') +
    '## Future improvements\n' + (improvements.length ? improvements.map(i => '- ' + i).join('\n') : '- To be listed.') + '\n\n' +
    '---\n*Generated by ProjectLab · ' + date + '*\n';
}

function downloadFile(filename, content, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function esc(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}