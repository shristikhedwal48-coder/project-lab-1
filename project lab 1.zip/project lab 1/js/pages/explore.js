import { CATEGORIES, searchSubjects } from '../data/subjects.js';
import { subjectCard } from '../components/cards.js';

const params = new URLSearchParams(location.search);
const state = {
  q: params.get('q') || '',
  category: params.get('category') || '',
  difficulty: params.get('difficulty') || '',
};

const searchInput = document.getElementById('search');
const catChips = document.getElementById('cat-chips');
const diffChips = document.getElementById('diff-chips');
const meta = document.getElementById('meta');
const results = document.getElementById('results');

searchInput.value = state.q;

catChips.innerHTML = [
  '<button class="chip" data-cat="" aria-pressed="' + (state.category === '') + '">All categories</button>'
].concat(CATEGORIES.map(c =>
  '<button class="chip" data-cat="' + c.id + '" aria-pressed="' + (state.category === c.id) + '">' + c.name + '</button>'
)).join('');

const DIFFS = ['beginner', 'intermediate', 'advanced'];
diffChips.innerHTML = [
  '<button class="chip" data-diff="" aria-pressed="' + (state.difficulty === '') + '">All levels</button>'
].concat(DIFFS.map(d =>
  '<button class="chip" data-diff="' + d + '" aria-pressed="' + (state.difficulty === d) + '">' + cap(d) + '</button>'
)).join('');

catChips.addEventListener('click', (e) => {
  const b = e.target.closest('.chip');
  if (!b) return;
  state.category = b.dataset.cat;
  syncPressed();
  render();
});

diffChips.addEventListener('click', (e) => {
  const b = e.target.closest('.chip');
  if (!b) return;
  state.difficulty = b.dataset.diff;
  syncPressed();
  render();
});

searchInput.addEventListener('input', () => {
  state.q = searchInput.value;
  render();
});

function syncPressed() {
  catChips.querySelectorAll('.chip').forEach(c =>
    c.setAttribute('aria-pressed', String(c.dataset.cat === state.category)));
  diffChips.querySelectorAll('.chip').forEach(c =>
    c.setAttribute('aria-pressed', String(c.dataset.diff === state.difficulty)));
}

function render() {
  const matched = searchSubjects(state.q, { category: state.category, difficulty: state.difficulty });
  meta.textContent = matched.length + ' subject' + (matched.length === 1 ? '' : 's') + ' found';

  if (matched.length === 0) {
    results.innerHTML = '<div class="empty-state"><h3>No subjects match your filters</h3><p>Try a different search term, clear filters, or browse by category above.</p></div>';
    return;
  }

  if (!state.q && !state.category) {
    results.innerHTML = CATEGORIES.map(cat => {
      const subjects = matched.filter(s => s.category === cat.id);
      if (subjects.length === 0) return '';
      return '<section class="category-block"><div class="category-head"><h2>' + cat.name + '</h2><span class="category-count">' + subjects.length + ' subject' + (subjects.length === 1 ? '' : 's') + '</span></div><div class="grid grid-3">' + subjects.map(subjectCard).join('') + '</div></section>';
    }).join('');
  } else {
    results.innerHTML = '<div class="grid grid-3">' + matched.map(subjectCard).join('') + '</div>';
  }

  results.querySelectorAll('.subject-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('a')) return;
      location.href = 'subject.html?id=' + card.dataset.subjectId;
    });
  });
}

function cap(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

syncPressed();
render();