import { renderNavbar } from './components/navbar.js';
import { renderFooter } from './components/footer.js';

const THEME_KEY = 'pl_theme';

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  try { localStorage.setItem(THEME_KEY, theme); } catch (_) {}
}

function initTheme() {
  let theme = 'light';
  try { theme = localStorage.getItem(THEME_KEY) || 'light'; } catch (_) {}
  applyTheme(theme);
}

function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme') || 'light';
  applyTheme(cur === 'dark' ? 'light' : 'dark');
}

function mountShared() {
  const navMount = document.getElementById('navbar-mount');
  const footMount = document.getElementById('footer-mount');
  if (navMount) navMount.innerHTML = renderNavbar();
  if (footMount) footMount.innerHTML = renderFooter();

  const themeBtn = document.getElementById('theme-toggle');
  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);

  const toggleBtn = document.getElementById('nav-toggle');
  const inner = document.querySelector('.navbar-inner');
  if (toggleBtn && inner) {
    toggleBtn.addEventListener('click', () => {
      inner.classList.toggle('open');
      toggleBtn.setAttribute('aria-expanded', String(inner.classList.contains('open')));
    });
  }
}

function markActive() {
  const file = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === file) {
      a.setAttribute('aria-current', 'page');
    }
  });
}

initTheme();
mountShared();
markActive();

window.PL = { applyTheme, toggleTheme };