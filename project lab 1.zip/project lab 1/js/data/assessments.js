export const ASSESSMENTS = {
  python: {
    title: 'Python — Foundations Assessment',
    passingScore: 0.7,
    questions: [
      {
        id: 'py-q1',
        type: 'mc',
        question: 'What is the primary difference between a list and a tuple in Python?',
        options: ['Lists are faster', 'Tuples are immutable; lists are mutable', 'Tuples can only hold strings', 'Lists cannot be iterated'],
        answer: 1,
        explanation: 'Tuples cannot be changed after creation; lists can. This makes tuples useful for fixed collections and for dict keys.',
      },
      {
        id: 'py-q2',
        type: 'mc',
        question: 'Which is the idiomatic way to safely accumulate into a dict by key?',
        options: ['d[k] += v', 'd[k] = d.get(k, 0) + v', 'd.append((k, v))', 'd += {k: v}'],
        answer: 1,
        explanation: 'd.get(k, 0) returns 0 when k is missing, avoiding a KeyError on the first insertion.',
      },
      {
        id: 'py-q3',
        type: 'short',
        question: 'Write the expression that returns the number of items in the list `xs`.',
        accept: ['len(xs)'],
        explanation: 'len() returns the number of items in any sequence.',
      },
      {
        id: 'py-q4',
        type: 'mc',
        question: 'You read a CSV amount and get the string "12.50". What should you do before summing it with other amounts?',
        options: ['Sum it directly', 'Convert with float()', 'Convert with int()', 'Strip the decimal point'],
        answer: 1,
        explanation: 'Summing strings concatenates them. float() converts to a number.',
      },
      {
        id: 'py-q5',
        type: 'interpret',
        question: 'A colleague writes `totals[category] += amount` inside a loop and gets a KeyError on the first iteration. Explain why, and how to fix it.',
        reference: 'On the first iteration `category` is not yet a key in `totals`, so `totals[category]` raises KeyError. Fix: use `totals[category] = totals.get(category, 0) + amount`, or `totals.setdefault(category, 0)` then add.',
      },
    ],
  },
  sql: {
    title: 'SQL — Querying Assessment',
    passingScore: 0.7,
    questions: [
      {
        id: 'sql-q1',
        type: 'mc',
        question: 'What does LEFT JOIN preserve that INNER JOIN does not?',
        options: ['All rows from the left table, even unmatched', 'Only matching rows', 'Only the right table', 'Indexes'],
        answer: 0,
        explanation: 'LEFT JOIN keeps every row from the left table; unmatched rows have NULLs in the right table\'s columns.',
      },
      {
        id: 'sql-q2',
        type: 'mc',
        question: 'You GROUP BY category and compute SUM(quantity × price). What does each result row represent?',
        options: ['A product', 'An order', 'A category with its aggregated revenue', 'The whole table'],
        answer: 2,
        explanation: 'GROUP BY category collapses all rows of the same category into one result row with aggregated values.',
      },
      {
        id: 'sql-q3',
        type: 'mc',
        question: 'Which join condition correctly links `order_items` to `products`?',
        options: ['order_items.order_id = products.product_id', 'order_items.product_id = products.product_id', 'order_items.quantity = products.unit_price', 'No join needed'],
        answer: 1,
        explanation: 'The shared identifier is product_id; that is the correct key relationship.',
      },
      {
        id: 'sql-q4',
        type: 'short',
        question: 'Write the SQL keyword pair that filters rows BEFORE grouping vs AFTER grouping.',
        accept: ['where/having', 'where having', 'where, having'],
        explanation: 'WHERE filters rows before aggregation; HAVING filters aggregated groups.',
      },
      {
        id: 'sql-q5',
        type: 'interpret',
        question: 'You want "average order value", but a teammate writes AVG(quantity × price) directly on the order_items table. Explain why this is wrong and how to fix it.',
        reference: 'AVG on line-item revenue averages lines, not orders. Orders with more lines are weighted higher, so the result is not true AOV. Fix: first aggregate per order in a subquery (SUM(quantity × price) GROUP BY order_id), then AVG over that.',
      },
    ],
  },
};

export function getAssessment(subjectId) {
  return ASSESSMENTS[subjectId] || null;
}