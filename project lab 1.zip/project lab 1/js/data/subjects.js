export const CATEGORIES = [
  { id: 'programming', name: 'Programming' },
  { id: 'data', name: 'Data Science and Analytics' },
  { id: 'ai', name: 'Artificial Intelligence' },
  { id: 'finance', name: 'Finance and Quantitative Skills' },
  { id: 'software', name: 'Software Development' },
];

export const SUBJECTS = [
  {
    id: 'python',
    name: 'Python',
    category: 'programming',
    level: 'beginner',
    duration: '6–8 weeks',
    blurb: 'The foundation language for data, automation, AI and scripting. Learn syntax, structures, functions and file handling by building real tools.',
    prerequisites: ['None — beginner-friendly'],
    objectives: [
      'Write and debug Python programs using variables, control flow and functions',
      'Work with lists, dictionaries, files and structured data',
      'Use libraries such as pandas and matplotlib for analysis',
      'Build a portfolio-ready Python project from a problem statement',
    ],
    skillChecklist: [
      'Variables, types and operators',
      'Control flow (if / for / while)',
      'Functions and modules',
      'Data structures (list, dict, set, tuple)',
      'File I/O and exceptions',
      'Intro to pandas and matplotlib',
    ],
    modules: [
      { level: 'beginner', title: 'Foundations', objectives: ['Understand what Python is and how to run it', 'Master variables, types and operators', 'Write conditional and loop-based logic'], projects: ['Personal Expense Tracker'] },
      { level: 'intermediate', title: 'Working with data', objectives: ['Use functions and modules to organise code', 'Read/write files and handle errors', 'Analyse structured data with pandas'], projects: [] },
      { level: 'advanced', title: 'Applied Python', objectives: ['Analyse financial and time-series data', 'Structure reusable project code', 'Present findings with clear visuals'], projects: [] },
    ],
  },
  {
    id: 'sql',
    name: 'SQL',
    category: 'data',
    level: 'beginner',
    duration: '4–6 weeks',
    blurb: 'Query, join and aggregate relational data — the most requested analytics skill in job listings.',
    prerequisites: ['None — beginner-friendly'],
    objectives: [
      'Write SELECT, WHERE, GROUP BY and JOIN queries',
      'Model relational data',
      'Answer business questions from data',
    ],
    skillChecklist: ['SELECT / WHERE / ORDER BY', 'Aggregations', 'JOINs', 'Subqueries', 'CTEs', 'Window functions (intro)'],
    modules: [
      { level: 'beginner', title: 'Querying Essentials', objectives: ['Filter and sort data', 'Aggregate metrics', 'Answer business questions'], projects: ['Retail Database Analysis'] },
      { level: 'intermediate', title: 'Joins & Segmentation', objectives: ['Multi-table analysis', 'Segment customers', 'Use CTEs for readability'], projects: [] },
    ],
  },
  {
    id: 'data-analytics',
    name: 'Data Analytics',
    category: 'data',
    level: 'beginner',
    duration: '8 weeks',
    blurb: 'Combine SQL, spreadsheets and visualisation to answer real business questions end-to-end.',
    prerequisites: ['None; SQL and spreadsheet basics help'],
    objectives: ['Frame an analytical question', 'Clean and analyse data', 'Communicate findings with dashboards'],
    skillChecklist: ['Question framing', 'Data cleaning', 'Exploratory analysis', 'Dashboarding', 'Storytelling with data'],
    modules: [
      { level: 'beginner', title: 'Analyst Fundamentals', objectives: ['Clean and explore data', 'Build a KPI dashboard'], projects: ['Sales Performance Dashboard'] },
    ],
  },
  {
    id: 'machine-learning',
    name: 'Machine Learning',
    category: 'ai',
    level: 'intermediate',
    duration: '10 weeks',
    blurb: 'Go from data to predictive models: regression, classification, evaluation and iteration.',
    prerequisites: ['Python basics', 'Intro statistics'],
    objectives: ['Frame ML problems correctly', 'Train, evaluate and iterate models', 'Interpret results responsibly'],
    skillChecklist: ['Train/test split', 'Linear & logistic regression', 'Tree-based models', 'Model evaluation', 'Feature engineering'],
    modules: [
      { level: 'intermediate', title: 'Supervised Learning Foundations', objectives: ['Train regression and classification models', 'Evaluate with appropriate metrics'], projects: ['House Price Prediction', 'Customer Churn Prediction'] },
    ],
  },
  {
    id: 'financial-analysis',
    name: 'Financial Analysis',
    category: 'finance',
    level: 'beginner',
    duration: '5 weeks',
    blurb: 'Read financial statements and answer: is this business healthy, profitable and efficient?',
    prerequisites: ['None; accounting basics helpful'],
    objectives: ['Interpret income statement, balance sheet and cash flow', 'Compute and interpret key ratios', 'Summarise business health'],
    skillChecklist: ['Statement structure', 'Profitability ratios', 'Liquidity & solvency', 'Efficiency ratios', 'Common-size analysis'],
    modules: [
      { level: 'beginner', title: 'Reading Statements', objectives: ['Understand each statement', 'Compute basic ratios'], projects: ['Financial Statement Analysis'] },
    ],
  },
  {
    id: 'frontend',
    name: 'Frontend Development',
    category: 'software',
    level: 'beginner',
    duration: '8 weeks',
    blurb: 'Build responsive, accessible interfaces with modern HTML, CSS and JavaScript.',
    prerequisites: ['None — beginner-friendly'],
    objectives: ['Structure pages semantically', 'Build responsive layouts', 'Add interactivity with JavaScript'],
    skillChecklist: ['Semantic HTML', 'CSS layout (flex/grid)', 'Responsive design', 'DOM & events', 'Accessibility basics'],
    modules: [
      { level: 'beginner', title: 'Web Foundations', objectives: ['Build a responsive page', 'Add interactivity'], projects: [] },
    ],
  },
];

export function getSubjectById(id) {
  return SUBJECTS.find(s => s.id === id) || null;
}

export function getSubjectsByCategory(categoryId) {
  return SUBJECTS.filter(s => s.category === categoryId);
}

export function searchSubjects(query, { category = '', difficulty = '' } = {}) {
  const q = (query || '').trim().toLowerCase();
  return SUBJECTS.filter(s => {
    if (category && s.category !== category) return false;
    if (difficulty && s.level !== difficulty) return false;
    if (!q) return true;
    return (
      s.name.toLowerCase().includes(q) ||
      s.blurb.toLowerCase().includes(q) ||
      s.modules.some(m => m.projects.some(p => p.toLowerCase().includes(q)))
    );
  });
}