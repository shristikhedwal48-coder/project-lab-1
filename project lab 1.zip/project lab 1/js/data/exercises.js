export const PY_EXERCISES = [
  {
    id: 'py-sum-list',
    title: 'Sum of a list',
    difficulty: 'beginner',
    objective: 'Use a loop or sum() to aggregate values.',
    problem: 'Given a list of numbers, compute and print their total.\n\nExpected output for [10, 20, 30]: 60',
    starterCode: 'numbers = [10, 20, 30]\n\n# Compute the total of the numbers list.\n# Print the result.\ntotal = 0\nfor n in numbers:\n    total += n\nprint(total)\n',
    validator: (out) => normalize(out) === '60',
    hints: [
      'You can add each number to a running total using a loop.',
      'Python also has a built-in sum() function you can use on the list.',
      'The simplest correct answer is: print(sum(numbers))',
    ],
    solution: 'numbers = [10, 20, 30]\nprint(sum(numbers))\n',
    solutionExplanation: 'sum() iterates the list and adds the numbers. Both a manual loop and sum() are correct; sum() is idiomatic and clearer.',
  },
  {
    id: 'py-count-words',
    title: 'Count words',
    difficulty: 'beginner',
    objective: 'Split strings and count list length.',
    problem: 'Given the sentence stored in `sentence`, count the number of words and print the count.\n\nExpected output for "the quick brown fox": 4',
    starterCode: 'sentence = "the quick brown fox"\n\n# Print the number of words in the sentence.\n',
    validator: (out) => normalize(out) === '4',
    hints: [
      'A string has a .split() method that splits on whitespace by default.',
      'After splitting you get a list; use len() to count items.',
      'Try print(len(sentence.split())).',
    ],
    solution: 'sentence = "the quick brown fox"\nprint(len(sentence.split()))\n',
    solutionExplanation: 'split() with no argument splits on any whitespace and drops empty strings. len() returns the number of items.',
  },
  {
    id: 'py-dict-totals',
    title: 'Group totals in a dict',
    difficulty: 'intermediate',
    objective: 'Aggregate values into a dictionary by key.',
    problem: 'Given a list of (category, amount) tuples, compute the total per category and print each category sorted alphabetically with its total.\n\nExpected output:\nfood: 30\nrent: 100',
    starterCode: 'expenses = [("food", 10), ("rent", 100), ("food", 20)]\n\n# Compute totals per category, then print sorted alphabetically.\n',
    validator: (out) => normalize(out) === 'food: 30\nrent: 100',
    hints: [
      'Use a dictionary where the key is the category and the value is a running total.',
      'Use dict.get(category, 0) to avoid a KeyError the first time you see a category.',
      'To print sorted alphabetically: for cat in sorted(totals): print(f"{cat}: {totals[cat]}")',
    ],
    solution: 'expenses = [("food", 10), ("rent", 100), ("food", 20)]\ntotals = {}\nfor cat, amt in expenses:\n    totals[cat] = totals.get(cat, 0) + amt\nfor cat in sorted(totals):\n    print(f"{cat}: {totals[cat]}")\n',
    solutionExplanation: 'dict.get with a default handles first insertion. sorted(totals) sorts the keys; the loop prints each key with its accumulated value.',
  },
  {
    id: 'py-find-largest',
    title: 'Find the largest value',
    difficulty: 'intermediate',
    objective: 'Use max() with a key function.',
    problem: 'Given a list of (name, amount) tuples, print the NAME of the item with the largest amount.\n\nExpected output: rent',
    starterCode: 'items = [("food", 30), ("rent", 100), ("transport", 45)]\n\n# Print the name of the item with the largest amount.\n',
    validator: (out) => normalize(out) === 'rent',
    hints: [
      'max() accepts a key= function that decides what "largest" means.',
      'You want the item with the largest item[1] (the amount).',
      'Try: largest = max(items, key=lambda t: t[1]); then print(largest[0])',
    ],
    solution: 'items = [("food", 30), ("rent", 100), ("transport", 45)]\nlargest = max(items, key=lambda t: t[1])\nprint(largest[0])\n',
    solutionExplanation: 'max() with a key returns the tuple with the largest second element. Index [0] extracts the name.',
  },
  {
    id: 'py-debug-keyerror',
    title: 'Debug: KeyError',
    difficulty: 'intermediate',
    objective: 'Read a traceback and fix a dict access bug.',
    problem: 'The starter code crashes with a KeyError. Fix it so the program prints the totals correctly.\n\nExpected output:\nfood: 30\nrent: 100',
    starterCode: 'expenses = [("food", 10), ("rent", 100), ("food", 20)]\ntotals = {}\nfor cat, amt in expenses:\n    totals[cat] += amt\nfor cat in sorted(totals):\n    print(f"{cat}: {totals[cat]}")\n',
    validator: (out) => normalize(out) === 'food: 30\nrent: 100',
    hints: [
      'Read the traceback: which key is missing? On which line?',
      'totals[cat] += amt is shorthand for totals[cat] = totals[cat] + amt. The first iteration has no key yet.',
      'Use totals.get(cat, 0) so the first addition starts from 0.',
    ],
    solution: 'expenses = [("food", 10), ("rent", 100), ("food", 20)]\ntotals = {}\nfor cat, amt in expenses:\n    totals[cat] = totals.get(cat, 0) + amt\nfor cat in sorted(totals):\n    print(f"{cat}: {totals[cat]}")\n',
    solutionExplanation: 'dict.get(cat, 0) returns 0 when the key is absent, so the addition always succeeds.',
  },
];

export const SQL_EXERCISES = [
  {
    id: 'sql-count-customers',
    title: 'Count customers',
    difficulty: 'beginner',
    objective: 'Use COUNT(*) to count rows in a table.',
    problem: 'Write a query that returns a single column `n` containing the total number of rows in the `customers` table.',
    starterSql: '-- Count the rows in the customers table.\nSELECT COUNT(*) AS n FROM customers;\n',
    validator: (rows) => {
      if (!rows || rows.length !== 1) return { ok: false, message: 'Expected exactly one row.' };
      const val = Object.values(rows[0])[0];
      if (Number(val) !== 8) return { ok: false, message: 'Expected 8, got ' + val + '.' };
      return { ok: true, message: 'Correct — customers table has 8 rows.' };
    },
    hints: [
      'COUNT(*) counts all rows regardless of column values.',
      'Alias the result with AS n so the column is named n.',
      'Try: SELECT COUNT(*) AS n FROM customers;',
    ],
    solution: 'SELECT COUNT(*) AS n FROM customers;',
    solutionExplanation: 'COUNT(*) counts rows. AS n names the output column.',
  },
  {
    id: 'sql-products-over-15',
    title: 'Products over 15',
    difficulty: 'beginner',
    objective: 'Filter rows with WHERE.',
    problem: 'Return the `name` of every product whose `unit_price` is strictly greater than 15, ordered by name ascending.',
    starterSql: '-- List product names with unit_price > 15, ordered by name.\nSELECT name FROM products WHERE unit_price > 15 ORDER BY name ASC;\n',
    validator: (rows) => {
      if (!rows || rows.length === 0) return { ok: false, message: 'No rows returned — check your WHERE clause.' };
      const names = rows.map(r => r.name);
      const expected = ['Backpack', 'Desk lamp', 'Wireless mouse'];
      if (JSON.stringify(names) !== JSON.stringify(expected)) {
        return { ok: false, message: 'Expected ' + expected.join(', ') + ', got ' + names.join(', ') + '.' };
      }
      return { ok: true, message: 'Correct — three products match.' };
    },
    hints: [
      'Use WHERE unit_price > 15 to filter.',
      'Use ORDER BY name ASC to sort alphabetically.',
      'The matching products are Backpack (39), Desk lamp (24), Wireless mouse (19.99).',
    ],
    solution: 'SELECT name FROM products WHERE unit_price > 15 ORDER BY name ASC;',
    solutionExplanation: 'WHERE filters row-by-row. ORDER BY name ASC sorts alphabetically.',
  },
  {
    id: 'sql-revenue-per-category',
    title: 'Revenue per category',
    difficulty: 'intermediate',
    objective: 'JOIN two tables and GROUP BY a category.',
    problem: 'Return the `category` and the total revenue (`revenue`) for each product category, ordered by revenue descending. Revenue = SUM(quantity × unit_price). Round revenue to 2 decimals.',
    starterSql: '-- Revenue per category: SUM(quantity * unit_price) grouped by category.\n',
    validator: (rows) => {
      if (!rows || rows.length < 2) return { ok: false, message: 'Expected multiple category rows.' };
      const cats = rows.map(r => String(r.category));
      const required = ['Stationery', 'Home', 'Electronics', 'Bags'];
      const missing = required.filter(c => !cats.includes(c));
      if (missing.length) return { ok: false, message: 'Missing categories: ' + missing.join(', ') + '.' };
      const revenues = rows.map(r => Number(r.revenue));
      for (let i = 1; i < revenues.length; i++) {
        if (revenues[i] > revenues[i - 1] + 0.001) {
          return { ok: false, message: 'Rows are not in descending revenue order.' };
        }
      }
      return { ok: true, message: 'Correct — categories present and ordered by revenue descending.' };
    },
    hints: [
      'Join order_items and products on product_id.',
      'SELECT p.category, SUM(oi.quantity * p.unit_price) AS revenue, then GROUP BY p.category.',
      'Add ORDER BY revenue DESC, and ROUND(..., 2) for cleanliness.',
    ],
    solution: 'SELECT p.category,\n       ROUND(SUM(oi.quantity * p.unit_price), 2) AS revenue\nFROM order_items oi\nJOIN products p ON oi.product_id = p.product_id\nGROUP BY p.category\nORDER BY revenue DESC;',
    solutionExplanation: 'Joining order_items to products gives the price for each line. SUM of quantity × price per category produces revenue per category.',
  },
  {
    id: 'sql-top-customers',
    title: 'Top customers by revenue',
    difficulty: 'intermediate',
    objective: 'Combine three tables with a JOIN and GROUP BY.',
    problem: "Return each customer's name (`name`) and total revenue (`revenue`), ordered by revenue descending. Round to 2 decimals.",
    starterSql: '-- Customer name + total revenue across orders.\n',
    validator: (rows) => {
      if (!rows || rows.length === 0) return { ok: false, message: 'No rows returned.' };
      if (!('name' in rows[0]) || !('revenue' in rows[0])) {
        return { ok: false, message: 'Expected columns `name` and `revenue`.' };
      }
      const revenues = rows.map(r => Number(r.revenue));
      for (let i = 1; i < revenues.length; i++) {
        if (revenues[i] > revenues[i - 1] + 0.001) {
          return { ok: false, message: 'Not ordered by revenue descending.' };
        }
      }
      return { ok: true, message: 'Correct — customer names with revenue, ordered correctly.' };
    },
    hints: [
      'You need to join order_items → orders → customers → products (four tables).',
      'Group by c.customer_id, c.name to be safe against duplicate names.',
      'SUM(oi.quantity * p.unit_price) AS revenue, then ORDER BY revenue DESC.',
    ],
    solution: 'SELECT c.name,\n       ROUND(SUM(oi.quantity * p.unit_price), 2) AS revenue\nFROM order_items oi\nJOIN orders o    ON oi.order_id = o.order_id\nJOIN customers c ON o.customer_id = c.customer_id\nJOIN products p  ON oi.product_id = p.product_id\nGROUP BY c.customer_id, c.name\nORDER BY revenue DESC;',
    solutionExplanation: 'Four joins traverse from line items to customers. Grouping at the customer level gives total revenue per customer.',
  },
  {
    id: 'sql-left-join-customers',
    title: 'Customers with no orders',
    difficulty: 'advanced',
    objective: 'Use LEFT JOIN and IS NULL to find missing relationships.',
    problem: 'Return the `customer_id` and `name` of every customer who has NOT placed any order. Sort by customer_id.',
    starterSql: '-- Customers with zero orders using LEFT JOIN.\n',
    validator: (rows) => {
      if (!Array.isArray(rows)) return { ok: false, message: 'Unexpected result shape.' };
      if (rows.length === 0) {
        return { ok: true, message: 'Correct — in this sample every customer has placed at least one order. An empty result is the honest answer.' };
      }
      return { ok: true, message: 'Correct — returned ' + rows.length + ' customer(s) with no orders.' };
    },
    hints: [
      'Start FROM customers c.',
      'LEFT JOIN orders o ON c.customer_id = o.customer_id keeps every customer.',
      'Filter WHERE o.order_id IS NULL to keep only the unmatched ones.',
    ],
    solution: 'SELECT c.customer_id, c.name\nFROM customers c\nLEFT JOIN orders o ON c.customer_id = o.customer_id\nWHERE o.order_id IS NULL\nORDER BY c.customer_id;',
    solutionExplanation: 'LEFT JOIN keeps all customers. The rows with no matching order have NULL in o.order_id.',
  },
];

export function getPyExercise(id) { return PY_EXERCISES.find(e => e.id === id) || null; }
export function getSqlExercise(id) { return SQL_EXERCISES.find(e => e.id === id) || null; }

function normalize(s) {
  return String(s === null || s === undefined ? '' : s).replace(/\r\n/g, '\n').trim();
}