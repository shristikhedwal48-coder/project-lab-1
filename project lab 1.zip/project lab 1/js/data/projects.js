export const PROJECTS = [
  {
    id: 'personal-expense-tracker',
    title: 'Personal Expense Tracker',
    subjectId: 'python',
    difficulty: 'beginner',
    duration: '3–4 hours',
    industry: 'Personal Finance',
    blurb: 'Build a command-line tool that records expenses, categorises them and summarises where your money went.',
    objectives: ['Apply Python basics to a real problem', 'Structure data with dictionaries and lists', 'Persist data to a file'],
    tools: ['Python 3', 'Standard library only'],
    dataset: { name: 'expenses_sample.csv (synthetic)', note: 'Synthetic sample; not real financial records.' },
  },
  {
    id: 'retail-database-analysis',
    title: 'Retail Database Analysis',
    subjectId: 'sql',
    difficulty: 'beginner',
    duration: '3–5 hours',
    industry: 'Retail',
    blurb: 'Answer real business questions using joins and aggregation against a sample retail database.',
    objectives: ['Write multi-table queries', 'Aggregate business metrics', 'Interpret results in business terms'],
    tools: ['SQLite (browser workspace)'],
    dataset: { name: 'retail_sample.sql (synthetic)', note: 'Synthetic schema designed for teaching SQL; not real records.' },
  },
  {
    id: 'sales-performance-dashboard',
    title: 'Sales Performance Dashboard',
    subjectId: 'data-analytics',
    difficulty: 'beginner',
    duration: '4–6 hours',
    industry: 'Retail',
    blurb: 'Analyse synthetic retail sales data and produce a one-page dashboard answering core business questions.',
    objectives: ['Frame analytical questions', 'Clean and summarise data', 'Design a clear dashboard'],
    tools: ['Spreadsheet or Python'],
    dataset: { name: 'sales_sample.csv (synthetic)', note: 'Synthetic — clearly labelled; does not represent any real company.' },
  },
  {
    id: 'house-price-prediction',
    title: 'House Price Prediction',
    subjectId: 'machine-learning',
    difficulty: 'intermediate',
    duration: '6–8 hours',
    industry: 'Real Estate',
    blurb: 'Train and evaluate a regression model on a synthetic housing dataset, then interpret and document results.',
    objectives: ['Frame a supervised learning problem', 'Evaluate a regression model', 'Interpret results responsibly'],
    tools: ['Python (pandas, scikit-learn) in external environment'],
    dataset: { name: 'housing_sample.csv (synthetic)', note: 'Synthetic — modelled for teaching, not real market data.' },
  },
  {
    id: 'financial-statement-analysis',
    title: 'Financial Statement Analysis',
    subjectId: 'financial-analysis',
    difficulty: 'beginner',
    duration: '4–5 hours',
    industry: 'Finance',
    blurb: 'Read synthetic financial statements, compute key ratios and write a short business health assessment.',
    objectives: ['Interpret core financial statements', 'Compute key ratios', 'Turn numbers into business insight'],
    tools: ['Spreadsheet'],
    dataset: { name: 'statements_sample.csv (synthetic)', note: 'Synthetic statements constructed for teaching; not actual company records.' },
  },
  {
    id: 'customer-churn-prediction',
    title: 'Customer Churn Prediction',
    subjectId: 'machine-learning',
    difficulty: 'intermediate',
    duration: '8 hours',
    industry: 'Telecom',
    blurb: 'Build a classification workflow to predict churn, then communicate findings and limitations to a business audience.',
    objectives: ['Handle categorical data', 'Evaluate a classifier', 'Connect results to business action'],
    tools: ['Python (pandas, scikit-learn)'],
    dataset: { name: 'churn_sample.csv (synthetic)', note: 'Synthetic — does not represent any real subscriber base.' },
  },
];

export function getProjectById(id) {
  return PROJECTS.find(p => p.id === id) || null;
}

export function getFeaturedProjects(n = 3) {
  return PROJECTS.slice(0, n);
}

export function getProjectsBySubject(subjectId) {
  return PROJECTS.filter(p => p.subjectId === subjectId);
}