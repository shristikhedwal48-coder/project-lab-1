const DB_NAME = 'projectlab';
const DB_VERSION = 1;
const STORE_NAME = 'kv';

let dbPromise = null;
let useIdb = true;

function openDb() {
  if (dbPromise) return dbPromise;
  if (!('indexedDB' in window)) { useIdb = false; return Promise.resolve(null); }
  dbPromise = new Promise((resolve) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => { useIdb = false; resolve(null); };
    setTimeout(() => { if (!req.result && !dbPromise) { useIdb = false; resolve(null); } }, 1500);
  });
  return dbPromise;
}

async function idbGet(key) {
  const db = await openDb();
  if (!db) return null;
  return new Promise((res) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const r = tx.objectStore(STORE_NAME).get(key);
      r.onsuccess = () => res(r.result === undefined ? null : r.result);
      r.onerror = () => res(null);
    } catch (_) { res(null); }
  });
}

async function idbSet(key, value) {
  const db = await openDb();
  if (!db) return false;
  return new Promise((res) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(value, key);
      tx.oncomplete = () => res(true);
      tx.onerror = () => res(false);
    } catch (_) { res(false); }
  });
}

async function idbRemove(key) {
  const db = await openDb();
  if (!db) return;
  return new Promise((res) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(key);
      tx.oncomplete = () => res(true);
      tx.onerror = () => res(false);
    } catch (_) { res(false); }
  });
}

function lsGet(key) {
  try {
    const raw = localStorage.getItem('pl_' + key);
    return raw === null ? null : JSON.parse(raw);
  } catch (_) { return null; }
}

function lsSet(key, value) {
  try { localStorage.setItem('pl_' + key, JSON.stringify(value)); return true; }
  catch (_) { return false; }
}

export async function getItem(key, fallback = null) {
  if (useIdb) {
    const v = await idbGet(key);
    return v === null ? fallback : v;
  }
  const v = lsGet(key);
  return v === null ? fallback : v;
}

export async function setItem(key, value) {
  if (useIdb) {
    const ok = await idbSet(key, value);
    if (!ok) return lsSet(key, value);
    return true;
  }
  return lsSet(key, value);
}

export async function removeItem(key) {
  if (useIdb) return idbRemove(key);
  try { localStorage.removeItem('pl_' + key); return true; }
  catch (_) { return false; }
}

export function getItemSync(key, fallback = null) {
  const v = lsGet(key);
  return v === null ? fallback : v;
}

export function setItemSync(key, value) {
  return lsSet(key, value);
}

const _origSet = setItem;
export async function setItemMirrored(key, value) {
  const ok = await _origSet(key, value);
  lsSet(key, value);
  return ok;
}

const PROGRESS_KEY = 'progress_v1';

export async function getProgress() {
  return await getItem(PROGRESS_KEY, {
    subjectsExplored: [],
    projectsStarted: {},
    projectsCompleted: {},
    exercisesCompleted: {},
    assessments: {},
    skills: {},
    firstSeen: Date.now(),
    lastActive: Date.now(),
  });
}

export async function saveProgress(p) {
  p.lastActive = Date.now();
  return await setItemMirrored(PROGRESS_KEY, p);
}

export async function recordSubjectExplored(subjectId) {
  const p = await getProgress();
  if (!p.subjectsExplored.includes(subjectId)) {
    p.subjectsExplored.push(subjectId);
    await saveProgress(p);
  }
}

export async function recordProjectStarted(projectId) {
  const p = await getProgress();
  if (!p.projectsStarted[projectId]) {
    p.projectsStarted[projectId] = { startedAt: Date.now() };
    await saveProgress(p);
  }
}

export async function recordExerciseCompleted(exerciseId) {
  const p = await getProgress();
  p.exercisesCompleted[exerciseId] = { completedAt: Date.now() };
  await saveProgress(p);
}

export async function recordAssessment(subjectId, { score, total, answers }) {
  const p = await getProgress();
  p.assessments[subjectId] = { score, total, answers, submittedAt: Date.now() };
  await saveProgress(p);
}

export async function recordSkillPractised(skill) {
  const p = await getProgress();
  p.skills[skill] = (p.skills[skill] || 0) + 1;
  await saveProgress(p);
}

export async function completeProject(projectId, portfolioEntry) {
  const p = await getProgress();
  p.projectsCompleted[projectId] = portfolioEntry;
  await saveProgress(p);
}

export async function getPortfolioEntries() {
  const p = await getProgress();
  return p.projectsCompleted;
}